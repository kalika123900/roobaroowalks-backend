import { Component } from '@angular/core';
import { Router, NavigationEnd, NavigationStart } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'roobrooDemo';
  constructor(public _router: Router) {
    _router.events.subscribe(x => {

      if(x instanceof NavigationStart) {
      if(x.url == '/' && (localStorage.getItem("loginStatus")=="" || localStorage.getItem("loginStatus")==null || localStorage.getItem("loginStatus")==undefined)){
      this._router.navigate(['/login']);
      }
      if((x.url != '/login') && (localStorage.getItem("loginStatus")=="" || localStorage.getItem("loginStatus")==null || localStorage.getItem("loginStatus")==undefined)){
      this._router.navigate(['/login']);
      }
      // if(localStorage.getItem("loginStatus")=="" || localStorage.getItem("loginStatus")==null || localStorage.getItem("loginStatus")==undefined){
      //   this._router.navigate(['/login']);
      //   }

      }
      }
      );

 }
}



// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   title = 'roobrooDemo';
// }
