import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule  } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { NgxSpinnerModule } from 'ngx-spinner';
import { DatePickerModule } from '@syncfusion/ej2-angular-calendars';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { AddbannerComponent } from './component/addbanner/addbanner.component';
import { AddTestimonialsComponent } from './component/add-testimonials/add-testimonials.component';
import { UnforgettableMemoriesComponent } from './component/unforgettable-memories/unforgettable-memories.component';
import { MobileAppComponent } from './component/mobile-app/mobile-app.component';
import { TravellerResCentreComponent } from './component/traveller-res-centre/traveller-res-centre.component';
import { ReadWriteReviewComponent } from './component/read-write-review/read-write-review.component';
import { TripAdvisorComponent } from './component/trip-advisor/trip-advisor.component';
import { RestDataService } from './rest-data.service';
import { SidemenuComponent } from './component/sidemenu/sidemenu.component';
import { HeaderComponent } from './component/header/header.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { KeyPointComponent } from './component/key-point/key-point.component';
import { SocialComponent } from './component/social/social.component';
import { TrvlrResDetailsComponent } from './component/trvlr-res-details/trvlr-res-details.component';
import { CityMngmntComponent } from './component/city-mngmnt/city-mngmnt.component';
import { BookingComponent } from './component/booking/booking.component';
import { BlogComponent } from './component/blog/blog.component';
import { EventComponent } from './component/event/event.component';
import { HistriComponent } from './component/histri/histri.component';
import { EventHighlightsComponent } from './component/event-highlights/event-highlights.component';
import { EventMoreImgComponent } from './component/event-more-img/event-more-img.component';
import { AboutComponent } from './component/about/about.component';
import { CareerComponent } from './component/career/career.component';
import { ContactComponent } from './component/contact/contact.component';
import { GuideMngmntComponent } from './component/guide-mngmnt/guide-mngmnt.component';
import { CityFeedbackComponent } from './component/city-feedback/city-feedback.component';
import { OurOfficeComponent } from './component/our-office/our-office.component';
import { BlogMoreImgComponent } from './component/blog-more-img/blog-more-img.component';
import { CultureMoreImgComponent } from './component/culture-more-img/culture-more-img.component';
import { CultureComponent } from './component/culture/culture.component';
import { BlogInstaImgComponent } from './component/blog-insta-img/blog-insta-img.component';
import { CityMoreImgComponent } from './component/city-more-img/city-more-img.component';
import { ClientFeedbackComponent } from './component/client-feedback/client-feedback.component';
import { TagsComponent } from './component/tags/tags.component';
import { LoginComponent } from './component/login/login.component';
import { MetaTagsComponent } from './component/meta-tags/meta-tags.component';
import { MetaTagsCitiesComponent } from './component/meta-tags-cities/meta-tags-cities.component';
import { MetaTagsCityWalksComponent } from './component/meta-tags-city-walks/meta-tags-city-walks.component';
import { MetaTagsBlogPostsComponent } from './component/meta-tags-blog-posts/meta-tags-blog-posts.component';
import { DatePipe } from '@angular/common';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

const APP_Routing: Routes =[
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'addbanner', component: AddbannerComponent },
  { path: 'add-testimonials', component: AddTestimonialsComponent },
  { path: 'unforgettable-memories', component: UnforgettableMemoriesComponent },
  { path: 'mobile-app', component: MobileAppComponent },
  { path: 'traveller-res-centre', component: TravellerResCentreComponent },
  { path: 'read-write-review', component: ReadWriteReviewComponent },
  { path: 'trip-advisor', component: TripAdvisorComponent },
  { path: 'home', component: HomeComponent },
  { path: 'key-point', component: KeyPointComponent },
  { path: 'social', component: SocialComponent },
  { path: 'trvlr-res-details', component: TrvlrResDetailsComponent },
  { path: 'city-mngmnt', component: CityMngmntComponent },
  { path: 'booking', component: BookingComponent },
  { path: 'blog', component: BlogComponent },
  { path: 'events', component: EventComponent },
  { path: 'history', component: HistriComponent },
  { path: 'event-highlights', component: EventHighlightsComponent },
  { path: 'event-more-img', component: EventMoreImgComponent },
  { path: 'about', component: AboutComponent },
  { path: 'career', component: CareerComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'guide-mngmnt', component: GuideMngmntComponent },
  { path: 'city-feedback', component: CityFeedbackComponent },
  { path: 'our-office', component: OurOfficeComponent },
  { path: 'blog-more-img', component: BlogMoreImgComponent },
  { path: 'culture-more-img', component: CultureMoreImgComponent },
  { path: 'culture', component: CultureComponent },
  { path: 'blog-insta-img', component: BlogInstaImgComponent },
  { path: 'city-more-img', component: CityMoreImgComponent },
  { path: 'client-feedback', component: ClientFeedbackComponent },
  { path: 'tags', component: TagsComponent },
  { path: 'meta-tags', component: MetaTagsComponent },
  { path: 'meta-tags-cities', component: MetaTagsCitiesComponent },
  { path: 'meta-tags-city-walks', component: MetaTagsCityWalksComponent },
  { path: 'meta-tags-blog-posts', component: MetaTagsBlogPostsComponent}

  ]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddbannerComponent,
    AddTestimonialsComponent,
    UnforgettableMemoriesComponent,
    MobileAppComponent,
    TravellerResCentreComponent,
    ReadWriteReviewComponent,
    TripAdvisorComponent,
    SidemenuComponent,
    HeaderComponent,
    DashboardComponent,
    KeyPointComponent,
    SocialComponent,
    TrvlrResDetailsComponent,
    CityMngmntComponent,
    BookingComponent,
    BlogComponent,
    EventComponent,
    HistriComponent,
    EventHighlightsComponent,
    EventMoreImgComponent,
    AboutComponent,
    CareerComponent,
    ContactComponent,
    GuideMngmntComponent,
    CityFeedbackComponent,
    OurOfficeComponent,
    BlogMoreImgComponent,
    CultureMoreImgComponent,
    CultureComponent,
    BlogInstaImgComponent,
    CityMoreImgComponent,
    ClientFeedbackComponent,
    TagsComponent,
    LoginComponent,
    MetaTagsComponent,
    MetaTagsCitiesComponent,
    MetaTagsCityWalksComponent,
    MetaTagsBlogPostsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(APP_Routing),
    AppRoutingModule,
    NgxSpinnerModule,
    DatePickerModule,
    CKEditorModule,
    AngularEditorModule,
    AngularFontAwesomeModule
  ],
  providers: [RestDataService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
