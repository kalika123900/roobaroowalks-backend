import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CityMoreImgComponent } from './city-more-img.component';

describe('CityMoreImgComponent', () => {
  let component: CityMoreImgComponent;
  let fixture: ComponentFixture<CityMoreImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CityMoreImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CityMoreImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
