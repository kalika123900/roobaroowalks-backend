import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $:any;
@Component({
  selector: 'app-city-more-img',
  templateUrl: './city-more-img.component.html',
  styleUrls: ['./city-more-img.component.css']
})
export class CityMoreImgComponent implements OnInit {
  myForm: any = FormGroup;
  walkList:any=[]
  cityDetails:any=[];
  imgUrl:any;
  images:any=[];
  walkObj:any={};
  imgArray:any=[]
  index:any;
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      walkTitle: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      city: new FormControl('',[Validators.required]),
      
    })
   }

  ngOnInit() {
    this.getCity()
    this. getImg()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  city_management(){
    this.router.navigate(['city-mngmnt'])
  }
  getCity(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  onSelectWalk(){
    this.spinner.show();
    let dataInfo= {
      "cityId":this.myForm.value.city.split('@')[0],
}
    this.service.postResponseMethod(dataInfo,"getWalkByCity").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       this.walkList=response.result
      console.log("getWalkByCity==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("getWalkByCity_error==>>"+JSON.stringify(err))
    })  
  }
  onSelectWalk_edit(){
    this.spinner.show();
    let dataInfo= {
      "cityId":this.walkObj.city.split('@')[0],
}
    this.service.postResponseMethod(dataInfo,"getWalkByCity").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       this.walkList=response.result
      console.log("getWalkByCity==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("getWalkByCity_error==>>"+JSON.stringify(err))
    })    
  }
  addImg(){
    this.spinner.show();
    let dataInfo= {
        "walkId" : this.myForm.value.walkTitle.split('@')[0],
        "cityId" :this.myForm.value.city.split('@')[0],
          "client_imgs" : this.imgUrl 
        
    }
    this.service.postResponseMethod(dataInfo,"addMore_clientImgs").subscribe(response=>{
      if(response.responseCode==200){
        this.getImg()
       this.spinner.hide();
       $("#feedback").modal("hide");
      console.log("addMore_clientImgs==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("addMore_clientImgs_error==>>"+JSON.stringify(err))
    })
    }
  onSelectFile_clientImg(event) {
      
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.readAsDataURL(event.target.files[0]); 
  
      reader.onload = (event:any) => {
        this.imgUrl = event.target.result;
        // console.log(this.guideUrl);
      }
    }
  }
  getImg(){
    this.spinner.show();
    this.service.getResponseMethod("get_clientImg").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.images=res.clientImgLists;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  imageData(){
    return this.images.filter((item)=>item.client_imgs.length!=0)
  }
  editImg(val){
    this.walkObj=val;
    this.imgArray=this.walkObj.client_imgs   
  }
  remImg(val){
    this.index=val
    if(this.index != -1) {
      this.imgArray.splice(this.index, 1);
    }
  }
  updateImg(){
    this.spinner.show();
    let dataInfo= {
      "walkId":this.walkObj._id,
      "client_imgs" :this.imgArray
    }
      this.service.postResponseMethod(dataInfo,"editMore_clientImgs").subscribe(response=>{
          if(response.responseCode==200){
          this.spinner.hide();
          this.getImg()
          $("#feedbackEdit").modal("hide");
          console.log("editMore_clientImgs==>>"+JSON.stringify(response))
          } else{
          this.spinner.hide();
          alert(response.responseMessage);
       }  
       
         },err=>{
          this.spinner.hide();
          alert("Something went wrong!")
          console.log("editMore_clientImgs_error==>>"+JSON.stringify(err))
         }) 
  }

}
