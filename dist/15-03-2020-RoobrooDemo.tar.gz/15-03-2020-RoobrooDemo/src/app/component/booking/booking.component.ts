import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
declare var $:any;
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  myForm: any = FormGroup;
  bookings:any=[]
  obj:any={}
  orderId:any;
  object_1:any={}
  paymntId:any;
  bookingDate:any;
  orderBooking:any=[]
  show:any=false;
  guideList:any=[]
  data:any={};
  guides:any={}
  walklist:any;
  age:any;
  travlrdetail:any=[]
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      planTitle: new FormControl('',[Validators.required]),
      PlanDesc: new FormControl('',[Validators.required]),
      FormTitle: new FormControl('',[Validators.required]),


})
   }

  ngOnInit() {
    this.getBooking()
  this.getGuideList()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  getGuideList(){
    this.spinner.show();
    this.service.getResponseMethod("get_AddGuide").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.guideList=res.guides;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  getBooking(){
    this.spinner.show();
    this.service.getResponseMethod("getBooking").subscribe(res=>{
      if(res.responseCode==200){
      console.log(JSON.stringify(res));
      this.spinner.hide();
      this.bookings=res.lists;

      }
     },
     (err)=>{
       this.spinner.hide();
       console.log(err)
    });
  }

 view(val){
this.obj=val
this.orderId=this.obj._id
 }
 del(){
  let dataInfo= {
    "orderId":this.orderId
  }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"deleteBooking").subscribe(response=>{
    if(response.responseCode==200){
    console.log("deleteBooking==>>"+JSON.stringify(response))
    this.getBooking()
    this.spinner.hide();
    $("#delete").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}

  },err=>{
    this.spinner.hide();
    console.log("deleteBooking_error==>>"+JSON.stringify(err))
  })
 }
 cnclDel(){
  $("#delete").modal("hide");
}
edit(val){
  this.object_1=val
  this.paymntId=this.object_1.paymentId
  this.bookingDate=this.object_1.createdAt
  this.orderBooking=this.object_1.orderedBooking
  this.travlrdetail=this.object_1.orderedBooking.bookingDetail
}
// calculate(val){
//   this.age=val
//   let sum=0
// for(let i=0;i<this.travlrdetail.length;i++){
//   if(this.age<5){
//    sum=sum+0
//   }else if(this.age>5 && this.age<18){
// sum=sum
//   }else if( this.age>18){
// sum=sum
//   }
//   this.orderBooking.totalPrice=sum
// }

// }
updateBooking(){
  this.spinner.show();
 this.service.postResponseMethod(this.object_1,"updateBooking").subscribe(response=>{
    if(response.responseCode==200){
      this.getBooking()
     this.spinner.hide();
     $("#edit").modal("hide");
    console.log("updateBooking==>>"+JSON.stringify(response))
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}

  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
    console.log("updateBooking_error==>>"+JSON.stringify(err))
  })
}
searchBookingWalks(){
  let dataInfo= {
    "srch_guide" :this.data.search
  }
  this.service.postResponseMethod(dataInfo,"wlkNmbkngSrc").subscribe(response=>{
    if(response.responseCode==200){
    this.bookings=response.data
    this.walklist=response.data[0].orderedBooking[0].walkNme
    // if(response.data.length!=0){
      this.show=true
    // }
    console.log("wlkNmbkngSrc==>>"+JSON.stringify(response))
   } else{
    alert(response.responseMessage);
  }

  },err=>{
    console.log("wlkNmbkngSrc_error==>>"+JSON.stringify(err))
  })
  }
  assignGuide(val){
    this.guides=val
      let dataInfo= {
	      "walkName": this.walklist,
        "guidData":{
          "cityName":this.guides.name,
          "name":this.guides.cityName
        }
        }


      this.service.postResponseMethod(dataInfo,"assignGuide").subscribe(response=>{
        if(response.responseCode==200){
      alert(response.responseMessage)
        console.log("assignGuide==>>"+JSON.stringify(response))
       } else{
        alert(response.responseMessage);
      }

      },err=>{
        console.log("assignGuide_error==>>"+JSON.stringify(err))
      })
      }
}
