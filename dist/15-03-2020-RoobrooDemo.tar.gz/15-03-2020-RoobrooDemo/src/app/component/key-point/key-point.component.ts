import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $:any;
@Component({
  selector: 'app-key-point',
  templateUrl: './key-point.component.html',
  styleUrls: ['./key-point.component.css']
})
export class KeyPointComponent implements OnInit {
  activity:any=[];
  act:any={};
  edit:any={};imgUrl:any;
  constructor(private service: RestDataService,private router: Router, private spinner: NgxSpinnerService) {
    
   }

  ngOnInit() {
   this.getKeyPoints()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  getKeyPoints(){
    this.spinner.show();
    this.service.getResponseMethod("get_homeActivty").subscribe(res=>{
      if(res.responseCode==200){
      console.log(JSON.stringify(res)); 
      this.spinner.hide();
      this.activity=res.homeActvtys[0].activty;
      }
     },
     (err)=>{
       this.spinner.hide();
       console.log(err)
    });
  }
  editData(val){
this.act=val
this.edit.id=this.act._id
this.edit.title=this.act.actTitle
this.imgUrl=this.act.actImgs
}
update(){
  this.spinner.show();
  let dataInfo= {
    "homeActId":this.edit.id,
    "actTitle":this.edit.title,
    "actImgs":this.imgUrl,
 
      
      }
      this.service.postResponseMethod(dataInfo,"edit_hmeAct").subscribe(response=>{
        if(response.responseCode==200){
        this.spinner.hide();
        console.log("edit_hmeAct==>>"+JSON.stringify(response));
        this.getKeyPoints()
         $("#edit").modal("hide");
       } else{
        this.spinner.hide(); 
        alert(response.responseMessage);
    }  
    
      },err=>{
        this.spinner.hide();
         alert("Something went wrong!")
        console.log("edit_hmeAct_error==>>"+JSON.stringify(err))
      })
}
onSelectFile_img(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();

    reader.readAsDataURL(event.target.files[0]); 

    reader.onload = (event:any) => {
      this.imgUrl = event.target.result;
      console.log(this.imgUrl);
    }
  }
}
}
