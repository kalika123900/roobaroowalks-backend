import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.css']
})
export class TagsComponent implements OnInit {
  data:any={};
  tagList:any=[];
  tagObj:any={}
  categoryList:any=[]
  CatObj:any={}
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) { }

  ngOnInit() {
  this.getTag()
  this.getCategory()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  addTag(){
    let dataInfo= {
      "tagData" : this.data.tag
}
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"add_tag").subscribe(response=>{
          if(response.responseCode==200){
            this.data.tag='' 
          console.log("add_tag==>>"+JSON.stringify(response))
          this.getTag()
          this.spinner.hide();
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("add_tag_error==>>"+JSON.stringify(err))
        })
  }
  getTag(){
    this.spinner.show();
    this.service.getResponseMethod("get_tag").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.tagList=res.tagLists
        }
     
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    }); 
  }
  delTag(val){
    this.tagObj=val
    let dataInfo= {
      "tagId" :this.tagObj._id
}
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"delete_tag").subscribe(response=>{
          if(response.responseCode==200){
          console.log("delete_tag==>>"+JSON.stringify(response))
          this.getTag()
          this.spinner.hide();
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("delete_tag_error==>>"+JSON.stringify(err))
        })
  }
  addcategory(){
    let dataInfo= {
      "category" : this.data.category
}
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"addCategory").subscribe(response=>{
          if(response.responseCode==200){
            this.data.category='' 
          console.log("addCategory==>>"+JSON.stringify(response))
          this.getCategory()
          this.spinner.hide();
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("addCategory_error==>>"+JSON.stringify(err))
        })  
  }
  getCategory(){
    this.spinner.show();
    this.service.getResponseMethod("getCategory").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.categoryList=res.succ
        }
     
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    }); 
  }
  delCat(val){
    this.CatObj=val
    let dataInfo= {
      "id" :this.CatObj._id
}
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"deleteCategory").subscribe(response=>{
          if(response.responseCode==200){
          console.log("deleteCategory==>>"+JSON.stringify(response))
          this.getCategory()
          this.spinner.hide();
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("deleteCategory_error==>>"+JSON.stringify(err))
        })
  }
  
}
