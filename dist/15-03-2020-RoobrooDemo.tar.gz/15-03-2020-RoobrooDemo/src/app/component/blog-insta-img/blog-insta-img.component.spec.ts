import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BlogInstaImgComponent } from './blog-insta-img.component';
describe('BlogInstaImgComponent', () => {
  let component: BlogInstaImgComponent;
  let fixture: ComponentFixture<BlogInstaImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogInstaImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogInstaImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
