import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $:any;


@Component({
  selector: 'app-blog-insta-img',
  templateUrl: './blog-insta-img.component.html',
  styleUrls: ['./blog-insta-img.component.css']
})
export class BlogInstaImgComponent implements OnInit {
  blogInsta:any=[]
  imgUrl:any;
  instaImg:any=[];
  instaObj:any={}
  editImgUrl:any;

  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) { }

  ngOnInit() {
    this.getinstaimg()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  getinstaimg(){
    this.spinner.show();
    this.service.getResponseMethod("get_instaImgs").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      console.log(JSON.stringify(res)); 
      this.instaImg=res.instaImgLists;
      
      }
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    });
  }
  addImg(){
    let dataInfo= {
      "insta_imgs":this.imgUrl,
    }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"add_instaImgs").subscribe(response=>{
          if(response.responseCode==200){
            this.spinner.hide();
            this.getinstaimg()
            $("#feedback").modal("hide");
          console.log("add_instaImgs==>>"+JSON.stringify(response))
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("add_instaImgs_error==>>"+JSON.stringify(err))
        }) 
  }
  onSelectFile_img(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.readAsDataURL(event.target.files[0]); 
  
      reader.onload = (event:any) => {
        this.imgUrl= event.target.result;
        // console.log(this.imgUrl);
      }
    }
  }
  editInsta(val){
    this.instaObj=val
  }
  updateImg(){
        this.spinner.show();
        this.service.postResponseMethod(this.instaObj,"edit_instaImgs").subscribe(response=>{
          if(response.responseCode==200){
            this.spinner.hide();
            this.getinstaimg()
            $("#feedbackEdit").modal("hide");
          console.log("edit_instaImgs==>>"+JSON.stringify(response))
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("edit_instaImgs_error==>>"+JSON.stringify(err))
        }) 
  }
  onSelectFile_editImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.readAsDataURL(event.target.files[0]); 
  
      reader.onload = (event:any) => {
        this.editImgUrl= event.target.result;
        this.instaObj.insta_imgs= this.editImgUrl
        // console.log(this.imgUrl);
      }
    }
  }
  cnfrmDel(){
    this.spinner.show();
    let dataInfo= {
      "instaId" : this.instaObj._id
    }
    this.service.postResponseMethod(dataInfo,"delete_instaImgs").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       console.log("delete_instaImgs==>>"+JSON.stringify(response));
       $("#delete").modal("hide");
       this.getinstaimg()
       } else{
        this.spinner.hide();  
        alert(response.responseMessage);
  }   
    },err=>{
      this.spinner.hide();
      console.log("delete_instaImgs_error==>>"+JSON.stringify(err))
    }) 
  }
  cnclDel(){
   $("#delete").modal("hide");
  }
}
