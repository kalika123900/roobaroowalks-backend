import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuideMngmntComponent } from './guide-mngmnt.component';

describe('GuideMngmntComponent', () => {
  let component: GuideMngmntComponent;
  let fixture: ComponentFixture<GuideMngmntComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuideMngmntComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuideMngmntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
