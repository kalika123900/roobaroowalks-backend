import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;
@Component({
  selector: 'app-guide-mngmnt',
  templateUrl: './guide-mngmnt.component.html',
  styleUrls: ['./guide-mngmnt.component.css']
})
export class GuideMngmntComponent implements OnInit {
  myForm: any = FormGroup;
  cityDetails:any=[];
  guideUrl:any;
  guideList:any=[];
  edit:any={};
  updateImg:any;
  guideId:any;
  data:any={}
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      city: new FormControl('',[Validators.required]),
      name: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      fbLink: new FormControl('',[Validators.required]),
      twitterLink: new FormControl('',[Validators.required]),
      instaLink: new FormControl('',[Validators.required]),
    
     
    }) 
   }

  ngOnInit() {
  this.getCityList()
  this.getGuideList()
  }
  getCityList(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  addGuide(){
    this.spinner.show();
    let dataInfo= {
        "cityId" :this.myForm.value.city.split('@')[0],
        "cityName" :this.myForm.value.city.split('@')[1],
        "name" : this.myForm.value.name,
        "title" : this.myForm.value.title,
        "description" : this.myForm.value.desc,
        "image" :this.guideUrl,
        "facebookLink" : this.myForm.value.fbLink,
        "twitterLink" :  this.myForm.value.twitterLink,
        "instaLink" :  this.myForm.value.instaLink
    }
    this.service.postResponseMethod(dataInfo,"addGuide").subscribe(response=>{
      if(response.responseCode==200){
        this.getGuideList()
       this.spinner.hide();
       $("#myModalT").modal("hide");
      //  this.actionType='modal'
      console.log("addGuide==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("addGuide_error==>>"+JSON.stringify(err))
    })
    }
    onSelectFile_guideImg(event) {
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
    
        reader.readAsDataURL(event.target.files[0]); 
    
        reader.onload = (event:any) => {
          this.guideUrl = event.target.result;
          console.log(this.guideUrl);
        }
      }
    }
    getGuideList(){
      this.spinner.show();
      this.service.getResponseMethod("get_AddGuide").subscribe(res=>{
        if(res.responseCode==200){
          this.spinner.hide();
          console.log(JSON.stringify(res)); 
          this.guideList=res.guides;
          }
       },
       (err)=>{this.spinner.hide();
        console.log(err)
      });
    }
    editGuide(val){
      this.edit=val
    }
    updateGuide(){
      this.spinner.show();
      this.edit.cityId=this.edit.city.split('@')[0],
      this.edit.cityName=this.edit.city.split('@')[1],
      this.edit.city=this.edit.cityId+"@"+this.edit.cityName
      this.service.postResponseMethod(this.edit,"edit_AddGuide").subscribe(response=>{
        if(response.responseCode==200){
          this.getGuideList()
         this.spinner.hide();
         $("#myModalEdit").modal("hide");
        //  this.actionType='modal'
        console.log("edit_AddGuide==>>"+JSON.stringify(response))
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
    }  
    
      },err=>{
        this.spinner.hide();
         alert("Something went wrong!")
        console.log("edit_AddGuide_error==>>"+JSON.stringify(err))
      })
    }
    onSelectFile_EditImg(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
    
        reader.readAsDataURL(event.target.files[0]); 
    
        reader.onload = (event:any) => {
          this.updateImg = event.target.result;
          this.edit.image= this.updateImg
          // console.log(this.updateImg);
        }
      }
}
cnfrmDel(){
  let dataInfo= {
      "guideId" :this.edit._id
    }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"delete_addGuide").subscribe(response=>{
    if(response.responseCode==200){
    console.log("delete_addGuide==>>"+JSON.stringify(response))
    this.getGuideList()
    this.spinner.hide();
    $("#delete").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}  

  },err=>{
    this.spinner.hide();
    console.log("delete_addGuide_error==>>"+JSON.stringify(err))
  }) 
} 
cnclDel(){
  $("#delete").modal("hide");
}
searchGuide(){
  let dataInfo= {
    "srch_guide" :this.data.search
  }
  this.service.postResponseMethod(dataInfo,"search_addGuide").subscribe(response=>{
    if(response.responseCode==200){
    this.guideList=response.data
    console.log("search_addGuide==>>"+JSON.stringify(response))
   } else{
    alert(response.responseMessage);
  }  
  
  },err=>{
    console.log("search_addGuide_error==>>"+JSON.stringify(err))
  })
  }
}
