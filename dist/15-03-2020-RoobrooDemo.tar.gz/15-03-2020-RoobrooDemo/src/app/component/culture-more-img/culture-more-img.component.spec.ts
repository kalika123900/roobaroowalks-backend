import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CultureMoreImgComponent } from './culture-more-img.component';

describe('CultureMoreImgComponent', () => {
  let component: CultureMoreImgComponent;
  let fixture: ComponentFixture<CultureMoreImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CultureMoreImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CultureMoreImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
