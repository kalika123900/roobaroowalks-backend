import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravellerResCentreComponent } from './traveller-res-centre.component';

describe('TravellerResCentreComponent', () => {
  let component: TravellerResCentreComponent;
  let fixture: ComponentFixture<TravellerResCentreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravellerResCentreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravellerResCentreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
