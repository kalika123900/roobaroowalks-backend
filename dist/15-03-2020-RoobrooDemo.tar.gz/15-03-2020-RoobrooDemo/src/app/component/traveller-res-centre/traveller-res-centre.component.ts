import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-traveller-res-centre',
  templateUrl: './traveller-res-centre.component.html',
  styleUrls: ['./traveller-res-centre.component.css']
})
export class TravellerResCentreComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  travellers:any=[];
  object:any={};
  edit:any={};
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) { 
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      link:new FormControl('',[Validators.required]),
      
}) }

  ngOnInit() {
   this.getTrvlrs()
  }
  getTrvlrs(){
    this.spinner.show();
    this.service.getResponseMethod("get_travelr").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
      this.travellers=res.data[0].travelr;
        }
      
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    });
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  editData(val){
    this.object=val
    this.edit.id=this.object._id
    this.edit.title=this.object.tvlrTitle
    this.edit.des=this.object.tvlrDesc
    this.edit.link=this.object.tvlrLink
    this.imgUrl=this.object.tvlrImgs
  }
  update(){
    let dataInfo= {
  "travelrId" : this.edit.id,
  "tvlrTitle" : this.edit.title,
  "tvlrImgs" : this.imgUrl,
  "tvlrDesc" : this.edit.des,
  "tvlrLink":this.edit.link
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"edit_travelr").subscribe(response=>{
          if(response.responseCode==200){
          console.log("edit_travelr==>>"+JSON.stringify(response))
          this.getTrvlrs()
          this.spinner.hide();
          $("#edit").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{  this.spinner.hide();
         alert("Something went wrong!")
          console.log("edit_travelr_error==>>"+JSON.stringify(err))
        })
  } 
  

  // save(){
  //   // alert("ok")
  //   let dataInfo= {
  //     "mobTitle":this.myForm.value.title,
  //     "mobImgs": this.imgUrl,
  //     "mobDesc":this.myForm.value.desc,
  //     "mobLink":this.myForm.value.link
  //   }
  //   this.service.postResponseMethod(dataInfo,"mobile_app").subscribe(response=>{
  //     if(response.responseCode==200){
  //     console.log("mobile_app==>>"+JSON.stringify(response))
  //     this.getTrvlrs()
  //    } else{
  //     alert(response.responseMessage);
  // }  
  
  //   },err=>{
  //     console.log("mobile_app_error==>>"+JSON.stringify(err))
  //   })
  //   }
    onSelectFile_img(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
  
        reader.readAsDataURL(event.target.files[0]); 
  
        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          console.log(this.imgUrl);
        }
      }
  }
}
