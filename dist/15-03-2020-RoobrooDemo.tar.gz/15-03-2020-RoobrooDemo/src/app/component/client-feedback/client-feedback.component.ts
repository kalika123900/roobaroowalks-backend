import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $:any;
@Component({
  selector: 'app-client-feedback',
  templateUrl: './client-feedback.component.html',
  styleUrls: ['./client-feedback.component.css']
})
export class ClientFeedbackComponent implements OnInit {
  myForm: any = FormGroup;
  walkList:any=[]
  cityDetails:any=[];
  imgUrl:any;
  data:any={};
  feedbckList:any=[];
  feedbckObj:any={}
  editImgUrl:any;
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      walkTitle: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      city: new FormControl('',[Validators.required]),
      
    })
   }

  ngOnInit() {
    this.getCity()
  
  
  
  }
   
  getCity(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  onSelectWalk(){
    this.spinner.show();
    let dataInfo= {
      "cityId":this.myForm.value.city.split('@')[0],
}
    this.service.postResponseMethod(dataInfo,"getWalkByCity").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       this.walkList=response.result
      console.log("getWalkByCity==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("getWalkByCity_error==>>"+JSON.stringify(err))
    })  
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  city_management(){
    this.router.navigate(['city-mngmnt'])
  }
  getWalkFeedbck(){
    this.spinner.show();
    let dataInfo= {
      "cityId" : this.myForm.value.city.split('@')[0],
      "walkId": this.myForm.value.walkTitle.split('@')[0]     
    }
    this.service.postResponseMethod(dataInfo,"get_walkFeedback").subscribe(response=>{
      if(response.responseCode==200){
      this.feedbckList=response.feedbck[0].feedbackData
       this.spinner.hide();
      console.log("get_walkFeedback==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("get_walkFeedback_error==>>"+JSON.stringify(err))
    })
  }
  addWalkFeedbck(){
    this.spinner.show();
    let dataInfo= {
        "cityId" : this.myForm.value.city.split('@')[0],
        "walkId":this.myForm.value.walkTitle.split('@')[0],
        "client_img":this.imgUrl,
        "slectWalkName":this.myForm.value.walkTitle.split('@')[1],
        "title":this.myForm.value.title,
        "desc":this.myForm.value.desc
    }
    this.service.postResponseMethod(dataInfo,"addWalk_feedback").subscribe(response=>{
      if(response.responseCode==200){
        this.getWalkFeedbck()
       this.spinner.hide();
       $("#feedback").modal("hide");
      //  this.actionType='modal'
      console.log("addWalk_feedback==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("addWalk_feedback_error==>>"+JSON.stringify(err))
    })
    }
    onSelectFile_clientImg(event) {
      
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
    
        reader.readAsDataURL(event.target.files[0]); 
    
        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          // console.log(this.guideUrl);
        }
      }
    }
    onSelectFile_upImg(event) {
      
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
    
        reader.readAsDataURL(event.target.files[0]); 
    
        reader.onload = (event:any) => {
          this.editImgUrl = event.target.result;
          this.feedbckObj.client_img=this.editImgUrl
          // console.log(this.guideUrl);
        }
      }
    }
      editfeedbck(val){
        this.feedbckObj=val
        
      }
      editWalkFeedbck(){
        this.spinner.show();
        let dataInfo= {
            "walkId":this.feedbckObj.slectWalkName.split('@')[0],
            "newFeedback":this.feedbckObj,
        }
        this.service.postResponseMethod(dataInfo,"edit_walkFeedback").subscribe(response=>{
          if(response.responseCode==200){
            this.getWalkFeedbck()
           this.spinner.hide();
           $("#feedbackEdit").modal("hide");
          //  this.actionType='modal'
          console.log("edit_walkFeedback==>>"+JSON.stringify(response))
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("edit_walkFeedback_error==>>"+JSON.stringify(err))
        })
        }
      cnfrmDel(){
        this.spinner.show();
        let dataInfo= {
          "cityId" : this.myForm.value.city.split('@')[0],
          "walkId" : this.myForm.value.walkTitle.split('@')[0],
          "feedbckId" :this.feedbckObj._id
 }
        this.service.postResponseMethod(dataInfo,"delete_walkFeedback").subscribe(response=>{
          if(response.responseCode==200){
           this.spinner.hide();
           console.log("delete_walkFeedback==>>"+JSON.stringify(response));
           $("#delete").modal("hide");
           this.getWalkFeedbck()
           } else{
            this.spinner.hide();  
            alert(response.responseMessage);
      }   
        },err=>{
          this.spinner.hide();
          console.log("delete_walkFeedback_error==>>"+JSON.stringify(err))
        }) 
      }
      cnclDel(){
       $("#delete").modal("hide");
      }
}
