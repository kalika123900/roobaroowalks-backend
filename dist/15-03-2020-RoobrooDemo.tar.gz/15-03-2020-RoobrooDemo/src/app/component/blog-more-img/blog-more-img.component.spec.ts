import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogMoreImgComponent } from './blog-more-img.component';

describe('BlogMoreImgComponent', () => {
  let component: BlogMoreImgComponent;
  let fixture: ComponentFixture<BlogMoreImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogMoreImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogMoreImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
