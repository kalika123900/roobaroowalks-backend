import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AngularEditorConfig } from '@kolkov/angular-editor';
declare var $: any;
@Component({
  selector: 'app-blog-more-img',
  templateUrl: './blog-more-img.component.html',
  styleUrls: ['./blog-more-img.component.css']
})
export class BlogMoreImgComponent implements OnInit {

  myForm: any = FormGroup;
  blogs: any = [];
  imgUrl: any;
  imgArray: any = [];
  blogObj: any = {}
  index: any;
  upImgUrl: any;
  info: any = {}
  obj: any = {}
  blogDesc: any = {}
  public Editor = ClassicEditor;
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '10rem',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    sanitize: true,
    toolbarPosition: 'top',
  };
  constructor(private router: Router, private spinner: NgxSpinnerService, private service: RestDataService) {
    this.myForm = new FormGroup({
      blog: new FormControl('', [Validators.required]),
      desc: new FormControl('', [Validators.required]),
      title: new FormControl('', [Validators.required]),
    })
  }

  ngOnInit() {
    this.getBlog()
  }
  dashboard() {
    this.router.navigate(['dashboard'])
  }
  getBlog() {
    this.spinner.show();
    this.service.getResponseMethod("getBlog").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.blogs = res.result.addBlog;
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  onSelectFile_img(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event: any) => {
        this.imgUrl = event.target.result;
        // console.log(this.imgUrl);
      }
    }
  }
  addImg() {
    let dataInfo = {
      "id": this.myForm.value.blog,
      "images": this.imgUrl,
      "description": this.myForm.value.desc,
      "imgTitle": this.myForm.value.title
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo, "addmoreImages").subscribe(response => {
      if (response.responseCode == 200) {
        this.spinner.hide();
        this.getBlog()
        $("#feedback").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!")
    })
  }
  blogsData() {
    return this.blogs.filter((item) => item.moreImages.length != 0)
  }
  editMoreImg(val) {
    this.blogObj = val;
    this.imgArray = this.blogObj.moreImages
    // this.info.blogTitle=this.blogObj.title
    // this.info.desc=this.blogObj.moreImages.description

  }
  remImg(val) {
    this.index = val
    if (this.index != -1) {
      this.imgArray.splice(this.index, 1);
    }
  }
  //   editDesc(val,desc){
  // this.obj=val
  // this.blogDesc=desc
  // console.log("=====>",this.obj)
  // console.log(JSON.stringify(val))
  // }
  updateImg() {
    this.spinner.show();
    let dataInfo = {
      "id": this.blogObj._id,
      "moreImages": this.imgArray
    }
    this.service.postResponseMethod(dataInfo, "editmoreImages").subscribe(response => {
      if (response.responseCode == 200) {
        this.spinner.hide();
        this.getBlog()
        $("#feedbackEdit").modal("hide");
        console.log("editmoreImages==>>" + JSON.stringify(response))
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }

    }, err => {
      this.spinner.hide();
      alert("Something went wrong!")
      console.log("editmoreImages_error==>>" + JSON.stringify(err))
    })
  }

}
