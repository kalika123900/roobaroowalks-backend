import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;

@Component({
  selector: 'app-meta-tags-blog-posts',
  templateUrl: './meta-tags-blog-posts.component.html',
  styleUrls: ['./meta-tags-blog-posts.component.css']
})

export class MetaTagsBlogPostsComponent implements OnInit {
  myForm: any = FormGroup;
  metaTagList:any=[];
  edit:any={};
  walkData:any=[];

  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      city: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      metaTags: new FormControl('',[Validators.required]),
    })
  }

  ngOnInit() {
    this.getMetaTagList();
    this.get_walks_and_cities();
  }

  dashboard(){
    this.router.navigate(['dashboard'])
  }

  // get the blogs and display in select tag
  get_walks_and_cities(){
    this.spinner.show();
    this.service.getResponseMethod("getBlog").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        this.walkData=res.result.addBlog;
        console.log(res.result.addBlog);
      }
    },
    (err)=>{this.spinner.hide();
      console.log(err)
    });
  }

  // store in mongodb
  storeMetaTags(){
    this.spinner.show();
    let dataInfo= {
        "blog" : this.myForm.value.city,
        "title" : this.myForm.value.title,
        "metaTags" : this.myForm.value.metaTags
    }
    console.log(dataInfo);
    this.service.postResponseMethod(dataInfo,"storeBlogPostMetaTags").subscribe(response=>{
      console.log('inside');
      if(response.responseCode==200){
        // this.getGuideList()
        this.spinner.hide();
        $("#myModalMeta").modal("hide");
        //  this.actionType='modal'
        alert("Data stored Successfully");
        console.log("storeMetaTags==>>"+JSON.stringify(response))

        this.myForm.reset();

      } else{
        this.spinner.hide();
        alert(response.responseMessage);
      }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("storeMetaTags_error==>>"+JSON.stringify(err))
    })
  }


  // fetch from mongodb----------------
  getMetaTagList(){
    this.spinner.show();
    this.service.getResponseMethod("get_AddBlogPostMetaTags").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(res);
        this.metaTagList=res.data;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }

  // get the id of meta tag--------------------
  editGuide(val){
    this.edit=val
    console.log(val);
  }

  // delete the meta tag--------------------
  cnfrmDel(){
    let dataInfo= {
      "metaTagId" :this.edit._id
    }
    this.spinner.show();

    this.service.postResponseMethod(dataInfo,"delete_addBlogPostMetaTags").subscribe(response=>{
      if(response.responseCode==200){
        console.log("delete_addMetaTags==>>"+ response)
        this.getMetaTagList()
        this.spinner.hide();
        $("#delete").modal("hide");
        alert('Meta Tag deleted successful');
      } else{
        this.spinner.hide();
        alert(response.responseMessage);
      }
    },err=>{
      this.spinner.hide();
      console.log("delete_addWalkMetaTags_error==>>"+err)
    })
  }

  // update meta tags--------------------------
  updateMetaTags(){
    this.spinner.show();
    let dataInfo= {
      "metaTagId" :this.edit._id,
      "blog" : this.edit.blog,
      "title" : this.edit.title,
      "metaTags" : this.edit.metaTags
    }
    this.service.postResponseMethod(dataInfo,"edit_AddBlogPostMetaTags").subscribe(response=>{
      if(response.responseCode==200){
        this.getMetaTagList();
        this.spinner.hide();
        $("#myModalEdit").modal("hide");
        //  this.actionType='modal'
        // console.log("edit_AddMetaTags==>>"+response);
        console.log("edtdDtls==>>"+response);
        alert('Details Successfully Updated');

      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }

    },err=>{
      this.spinner.hide();
      alert("Something went wrong!")
      console.log("edit_AddCityMetaTags_error==>>"+err)
    })
  }

}
