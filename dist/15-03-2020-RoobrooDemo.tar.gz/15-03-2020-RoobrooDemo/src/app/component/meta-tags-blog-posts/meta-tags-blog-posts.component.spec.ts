import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetaTagsBlogPostsComponent } from './meta-tags-blog-posts.component';

describe('MetaTagsBlogPostsComponent', () => {
  let component: MetaTagsBlogPostsComponent;
  let fixture: ComponentFixture<MetaTagsBlogPostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetaTagsBlogPostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetaTagsBlogPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
