import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl,FormBuilder ,FormArray} from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import { DatePipe } from '@angular/common'
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

declare var $:any;
@Component({
  selector: 'app-culture',
  templateUrl: './culture.component.html',
  styleUrls: ['./culture.component.css']
})
export class CultureComponent implements OnInit {
  eventTab:any='AddBanner';
  myForm: any = FormGroup;
  myFormHighlight: any = FormGroup;
  submitted = false;
  imageErr:any;
  banners:any=[];
  highlight:Array<any>=[];
  highlightImgUrl:any;
  edit:any={};
  bnrHilight:Array<any>=[];
  bnrUrl:any;
  eventUrl:any;
  profileImg:any;
  blogs:any=[];
  blogObject:any={};
  Up_profileImg:any;
  upEventImg:any;
  data:any={};
  cityCulture:any=[];
  tagList:any=[];
  tagArray:any=[];
  itinerary:any=[];
  index:any;
  categoryList:any=[];
  cityList:any=[];
  editTags:any=[]
  public Editor = ClassicEditor;
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService,private _formBuilder: FormBuilder,public datepipe: DatePipe) {
      this.myForm = this._formBuilder.group({
        city: ['',Validators.required],
        title: ['',Validators.required],
        description: ['',Validators.required],
    });
    this.myFormHighlight = this._formBuilder.group({
      imgTitle: ['',Validators.required],
      imgLink: ['',Validators.required],
  })
  }
  /* onSelectFile_highlight(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.highlight.push(event.target.result);
      }
    }
  } */
  ngOnInit() {
    this.getBanrCulture();
    this.getTag();
    this.getCategory();
    this.getCity();
    this.imageErr=false;
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  managetab(val){
    this.eventTab=val;
    // alert(this.blogTab)
  }
  /*
   tags(){
  this.router.navigate(['tags'])
  } */
  more_images(){
    this.router.navigate(['culture-more-img'])
  }
  getBanrCulture(){
    this.spinner.show();
    this.service.getResponseMethod("getbannerCulture").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      this.banners=res.result;
      }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
  editBnr(val){
    this.edit=val
  }
  updatebannerCulture(){
    this.spinner.show();
    this.service.postResponseMethod(this.edit,"updatebannerCulture").subscribe(response=>{
      if(response.responseCode==200){
       this.getBanrCulture()
       this.spinner.hide();
       $("#myModal33").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
    }
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!");
    })
  }
  onSelectFile_bnr(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.bnrUrl = event.target.result;
        this.edit.image=this.bnrUrl
      }
    }
}
onSelectFile_highlight(event) {
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.highlightImgUrl= event.target.result;
      this.imageErr=false;
    }
  }
}
removeErr(){
  this.submitted = false;
  this.imageErr=false;
}
get highlightAddErr() { return this.myFormHighlight.controls; }
highlightsAddImg(){
  this.submitted = true;
    // stop here if form is invalid
     if(this.highlightImgUrl == undefined){
      this.imageErr = true;
      return;
    }
    if (this.myFormHighlight.invalid) {
      this.imageErr = true;
        return;
    }
  let dataInfo= {
   "images":this.highlightImgUrl,
   "imgTitle":this.myFormHighlight.value.imgTitle,
   "imgLink":this.myFormHighlight.value.imgLink
     }
      this.spinner.show();
      this.service.postResponseMethod(dataInfo,"addCultureHighlights").subscribe(response=>{
        if(response.responseCode==200){
          this.spinner.hide();
          this.getBanrCulture()
          $("#highlightsAdd").modal("hide");
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
    }
      },err=>{
        this.spinner.hide();
         alert("Something went wrong!")
      })
}
editBnrHilight(val){
  this.edit=val;
  this.bnrHilight=this.edit;
  /* this.info.blogTitle=this.blogObj.title
   this.info.desc=this.blogObj.highlights.imgDescription */

}
remImg(val){
  this.index=val
  if(this.index != -1) {
    this.bnrHilight.splice(this.index, 1);
  }
}
 highlightsEditImg(){
  this.spinner.show();
    let dataInfo= {
      "id": this.banners[0]._id,
      "highlights":this.bnrHilight
    }
      this.service.postResponseMethod(dataInfo,"editCultureHighlight").subscribe(response=>{
          if(response.responseCode==200){
          this.spinner.hide();
          this.getBanrCulture()
          $("#feedbackEdit").modal("hide");
          } else{
          this.spinner.hide();
          alert(response.responseMessage);
       }
         },err=>{
          this.spinner.hide();
          alert("Something went wrong!");
         })
  }
  get cityAddErr() { return this.myForm.controls; }
 addCityCulture(){
  this.submitted = true;
    // stop here if form is invalid
    if (this.myForm.invalid) {
        return;
    }
  this.spinner.show();
  let dataInfo= {
    "title":this.myForm.value.title,
    "description":this.myForm.value.description,
    "cityId":this.myForm.value.city,
   }
  this.service.postResponseMethod(dataInfo,"addCultureCity").subscribe(response=>{
    if(response.responseCode==200){
    this.getCityCulture()
     this.spinner.hide();
     $("#myModalAddEvent").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
  }
  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
  })
  }
  onSelectFile_blogImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.eventUrl = event.target.result;
      }
    }
}
onSelectFile_authImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.profileImg = event.target.result;
    }
  }
}
getCityCulture(){
  this.spinner.show();
  this.service.getResponseMethod("getbannerCulture").subscribe(res=>{
    if(res.responseCode==200){
    this.spinner.hide();
    if(res.result.length>0)
    {
      this.cityCulture = res.result[0].addCity;
    }
    else
    {
      this.cityCulture=[];
    }
    }
   },
   (err)=>{
    this.spinner.hide();
  });
}
editEvent(val){
  this.blogObject=val;
  this.editTags=this.blogObject.tags
}
editCityCulture(){
  this.spinner.show();
  this.blogObject.tags=this.editTags
 this.service.postResponseMethod(this.blogObject,"editCultureCity").subscribe(response=>{
    if(response.responseCode==200){
      this.getCityCulture()
     this.spinner.hide();
     $("#myModalEdit").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}
  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
  })
}
onSelectFile_editblogImg(event) {
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.upEventImg = event.target.result;
      this.blogObject.image=this.upEventImg
    }
  }
}
onSelectFile_editauthImg(event) {
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.Up_profileImg = event.target.result;
      this.blogObject.authorprofilePic=this.Up_profileImg
    }
  }
}
delEvent(){
  let dataInfo= {
    "id":this.blogObject._id
  }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"deleteCultureCity").subscribe(response=>{
    if(response.responseCode==200){
    this.getCityCulture()
    this.spinner.hide();
    $("#delete").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}
  },err=>{
    this.spinner.hide();
   })
}
cnclDelEvent(){
  $("#delete").modal("hide");
}
searchBlog(){
  let dataInfo= {
    "srchBlog" :this.data.search
  }
  this.service.postResponseMethod(dataInfo,"search_blog").subscribe(response=>{
    if(response.responseCode==200){
    this.blogs=response.data
    } else{
    alert(response.responseMessage);
  }
  },err=>{
    })
  }
  getTag(){
    this.spinner.show();
    this.service.getResponseMethod("get_tag").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        this.tagList=res.tagLists
        }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
onSelectTag(){
this.tagArray.push(this.myForm.value.tags)
}
addItinerary(){
  this.itinerary.push([]);
}
remItinerary(val){
  this.index=val
  if(this.index != -1) {
    this.itinerary.splice(this.index, 1);
  }
}
remTag(val){
  this.index=val
  if(this.index != -1) {
    this.tagArray.splice(this.index, 1);
  }
}
onChangeTag(){
  this.editTags.push(this.blogObject.tags)
}
updateTag(val){
  this.index=val
  if(this.index != -1) {
    this.editTags.splice(this.index, 1);
  }
}
getCity(){
  this.spinner.show();
  this.service.getResponseMethod("get_city").subscribe(res=>{
    if(res.responseCode==200){
      this.spinner.hide();
      this.cityList=res.cityList
      }
   },
   (err)=>{
    this.spinner.hide();
  });
}
getCategory(){
  this.spinner.show();
  this.service.getResponseMethod("getCategory").subscribe(res=>{
    if(res.responseCode==200){
      this.spinner.hide();
      this.categoryList=res.succ
      }
   },
   (err)=>{
    this.spinner.hide();
  });
}
}
