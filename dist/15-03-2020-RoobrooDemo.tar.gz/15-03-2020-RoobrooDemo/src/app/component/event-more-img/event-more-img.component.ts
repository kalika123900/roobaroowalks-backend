import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;
@Component({
  selector: 'app-event-more-img',
  templateUrl: './event-more-img.component.html',
  styleUrls: ['./event-more-img.component.css']
})
export class EventMoreImgComponent implements OnInit {
  myForm: any = FormGroup;
  submitted = false;
  imageErr:any;
  blogs:any=[];
  imgUrl:any;
  imgArray:any=[];
  blogObj:any={}
  index:any;
  upImgUrl:any;
  info:any={}
  obj:any={}
  blogDesc:any={}
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      blog: new FormControl('',[Validators.required]),
     /*  desc: new FormControl('',[Validators.required]), */
      title: new FormControl('',[Validators.required]),
    })
   }
  ngOnInit() {
    this.getEvent();
    this.imageErr=false;
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  events_page(){
    this.router.navigate(['events'])
  }
  getEvent(){
    this.spinner.show();
     this.service.getResponseMethod("getbannerEvent").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      this.blogs = res.result[0].addEvent;
      }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
  onSelectFile_img(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.imgUrl= event.target.result;
        this.imageErr = false;
      }
    }
  }
  removeErr(){
    this.submitted = false;
    this.imageErr=false;
  }
  get addImgErr() { return this.myForm.controls; }
  addImg(){
    this.submitted = true;
    // stop here if form is invalid
    if(this.imgUrl == undefined){
      this.imageErr = true;
      return;
    }
    if (this.myForm.invalid) {
        return;
    }
    let dataInfo= {
     "id":this.myForm.value.blog,
     "images":this.imgUrl,
     "imgTitle":this.myForm.value.title
    }
      this.spinner.show();
        this.service.postResponseMethod(dataInfo,"addEventMoreImages").subscribe(response=>{
          if(response.responseCode==200){
            this.spinner.hide();
            this.getEvent()
            $("#feedback").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
        })
  }
  blogsData(){
    return this.blogs.filter((item)=>item.moreImages.length!=0)
  }
  editMoreImg(val){
    this.blogObj=val;
    this.imgArray=this.blogObj.moreImages
    this.info.blogTitle=this.blogObj.title
    // this.info.desc=this.blogObj.moreImages.description
  }
  remImg(val){
    this.index=val
    if(this.index != -1) {
      this.imgArray.splice(this.index, 1);
    }
  }
//   editDesc(val,desc){
// this.obj=val
// this.blogDesc=desc
// console.log("=====>",this.obj)
// console.log(JSON.stringify(val))
// }
  updateImg(){
    this.spinner.show();
    let dataInfo= {
      "id":this.blogObj._id,
      "moreImages":this.imgArray
    }
      this.service.postResponseMethod(dataInfo,"editEventMoreImages").subscribe(response=>{
          if(response.responseCode==200){
          this.spinner.hide();
          this.getEvent()
          $("#feedbackEdit").modal("hide");
          } else{
          this.spinner.hide();
          alert(response.responseMessage);
       }
         },err=>{
          this.spinner.hide();
          alert("Something went wrong!")
         })
  }

}
