import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventMoreImgComponent } from './event-more-img.component';

describe('EventMoreImgComponent', () => {
  let component: EventMoreImgComponent;
  let fixture: ComponentFixture<EventMoreImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventMoreImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventMoreImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
