import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AngularEditorConfig } from '@kolkov/angular-editor';
declare var $: any;
@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '10rem',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    sanitize: true,
    toolbarPosition: 'top',
  };

  blogTab: any = 'AddBanner';
  myForm: any = FormGroup;
  banners: any = [];
  edit: any = {};
  bnrUrl: any;
  blogUrl: any;
  profileImg: any;
  blogs: any = [];
  blogObject: any = {};
  Up_profileImg: any;
  upBlogImg: any;
  data: any = {};
  tagList: any = [];
  tagArray: any = [];
  index: any;
  categoryList: any = [];
  editTags: any = [];
  cityList: any = [];;
  public Editor = ClassicEditor;
  constructor(private router: Router, private spinner: NgxSpinnerService, private service: RestDataService) {
    this.myForm = new FormGroup({
      cityId: new FormControl('', [Validators.required]),
      title: new FormControl('', [Validators.required]),
      desc: new FormControl('', [Validators.required]),
      blogTitle: new FormControl('', [Validators.required]),
      shortDes: new FormControl('', [Validators.required]),
      name: new FormControl('', [Validators.required]),
      date: new FormControl('', [Validators.required]),
      category: new FormControl('', [Validators.required]),
      tags: new FormControl('', [Validators.required]),
      facebook: new FormControl('', [Validators.required]),
      twitter: new FormControl('', [Validators.required]),
      insta: new FormControl('', [Validators.required]),
      authTitle: new FormControl('', [Validators.required]),
      authDesc: new FormControl('', [Validators.required]),
    })
  }

  ngOnInit() {
    this.getBanr();
    this.getTag();
    this.getCategory();
    this.getCity();
  }
  getCity() {
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.cityList = res.cityList
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  dashboard() {
    this.router.navigate(['dashboard'])
  }
  tags() {
    this.router.navigate(['tags'])
  }
  managetab(val) {

    this.blogTab = val;
    // alert(this.blogTab)
  }
  more_images() {
    this.router.navigate(['blog-more-img'])
  }
  instaImages() {
    this.router.navigate(['blog-insta-img'])
  }
  getBanr() {
    this.spinner.show();
    this.service.getResponseMethod("getbannerBlog").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.banners = res.result;
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  editBnr(val) {
    this.edit = val
  }
  updateBnr() {
    this.spinner.show();
    this.service.postResponseMethod(this.edit, "updatebannerBlog").subscribe(response => {
      if (response.responseCode == 200) {
        this.getBanr()
        this.spinner.hide();
        $("#myModal33").modal("hide");

      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!")

    })
  }
  onSelectFile_bnr(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.bnrUrl = event.target.result;
        this.edit.image = this.bnrUrl

      }
    }
  }
  addBlog() {
    //this.spinner.show();
    let dataInfo = {
      "cityId": this.myForm.value.cityId,
      "title": this.myForm.value.blogTitle,
      "ShortDesc": this.myForm.value.shortDes,
      "image": this.blogUrl,
      "authorName": this.myForm.value.name,
      "date": this.myForm.value.date,
      "category": this.myForm.value.category,
      "tags": this.tagArray,
      "facebookLink": this.myForm.value.facebook,
      "twitterLink": this.myForm.value.twitter,
      "instagramLink": this.myForm.value.insta,
      "authorTitle": this.myForm.value.authTitle,
      "authorDescription": this.myForm.value.authDesc,
      "authorprofilePic": this.profileImg
    }
    this.service.postResponseMethod(dataInfo, "addBlog").subscribe(response => {
      if (response.responseCode == 200) {
        this.getBlog()
        this.spinner.hide();
        $("#myModalAddBlog").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }

    }, err => {
      this.spinner.hide();
      alert("Something went wrong!");
    })
  }
  onSelectFile_blogImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.blogUrl = event.target.result;
      }
    }
  }
  onSelectFile_authImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.profileImg = event.target.result;
      }
    }
  }
  getBlog() {
    this.spinner.show();
    this.service.getResponseMethod("getBlog").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.blogs = res.result.addBlog;
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  editBlog(val) {
    this.blogObject = val;
    this.editTags = this.blogObject.tags
  }
  updateBlog() {
    this.spinner.show();
    this.blogObject.tags = this.editTags
    this.service.postResponseMethod(this.blogObject, "updateBlog").subscribe(response => {
      if (response.responseCode == 200) {
        this.getBlog()
        this.spinner.hide();
        $("#myModalEdit").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!");
    })
  }
  onSelectFile_editblogImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.upBlogImg = event.target.result;
        this.blogObject.image = this.upBlogImg
      }
    }
  }
  onSelectFile_editauthImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.Up_profileImg = event.target.result;
        this.blogObject.authorprofilePic = this.Up_profileImg
      }
    }
  }
  delBlog() {
    let dataInfo = {
      "id": this.blogObject._id
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo, "deleteBlog").subscribe(response => {
      if (response.responseCode == 200) {
        this.getBlog()
        this.spinner.hide();
        $("#delete").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
    })
  }
  cnclDelBlog() {
    $("#delete").modal("hide");
  }
  searchBlog() {
    let dataInfo = {
      "srchBlog": this.data.search
    }
    this.service.postResponseMethod(dataInfo, "search_blog").subscribe(response => {
      if (response.responseCode == 200) {
        this.blogs = response.data
      } else {
        alert(response.responseMessage);
      }
    }, err => {
    })
  }
  getTag() {
    this.spinner.show();
    this.service.getResponseMethod("get_tag").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.tagList = res.tagLists
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  onSelectTag() {
    this.tagArray.push(this.myForm.value.tags)
  }
  remTag(val) {
    this.index = val
    if (this.index != -1) {
      this.tagArray.splice(this.index, 1);
    }
  }
  onChangeTag() {
    this.editTags.push(this.blogObject.tags)
  }
  updateTag(val) {
    this.index = val
    if (this.index != -1) {
      this.editTags.splice(this.index, 1);
    }
  }
  getCategory() {
    this.spinner.show();
    this.service.getResponseMethod("getCategory").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.categoryList = res.succ
      }

    },
      (err) => {
        this.spinner.hide();
      });
  }
}
