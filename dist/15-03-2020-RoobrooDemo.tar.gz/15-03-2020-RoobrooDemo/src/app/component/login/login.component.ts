import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  myForm: any = FormGroup;
  // emailForm:any=FormGroup;
  otpForm:any=FormGroup;
  formtab:any='login'
  data:any={}
  constructor(private spinner: NgxSpinnerService,private service: RestDataService,private router: Router) {
    this.myForm = new FormGroup({
      emailId:new FormControl('',[Validators.required,Validators.pattern("[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}")]),
      loginPswrd: new FormControl('',[Validators.required]),
    
}) 
// this.emailForm = new FormGroup({
//   email: new FormControl('',[Validators.required,Validators.pattern("[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}")]),

// }) 
this.otpForm = new FormGroup({
  otp: new FormControl('',[Validators.required]),

}) 
   }

  ngOnInit() {
  }
  login(){
    this.spinner.show();
    let dataInfo= {
      "username" :this.myForm.value.emailId,
      "password" :this.myForm.value.loginPswrd
    }
    this.service.postResponseMethod(dataInfo,"admin_Login").subscribe(response=>{
      if(response.responseCode==200){
        localStorage.setItem("loginStatus","isLogin")
        this.router.navigate(['dashboard'])
       this.spinner.hide();
      console.log("admin_Login==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("admin_Login_error==>>"+JSON.stringify(err))
    })
  }
  
  getOtp(){
    this.spinner.show();
    let dataInfo= {
    }
    this.service.postResponseMethod(dataInfo,"admin_forgotPassword").subscribe(response=>{
      if(response.responseCode==200){
        this.formtab='verifyOtp' 
        alert("Your OTP has been sent on the registered email-id")
       this.spinner.hide();
      console.log("admin_forgotPassword==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("admin_forgotPassword_error==>>"+JSON.stringify(err))
    })
  }
  sendOtp(){
    this.spinner.show();
    let dataInfo= {
      "otp" :this.otpForm.value.otp,
    }
    this.service.postResponseMethod(dataInfo,"admin_verifyOtp").subscribe(response=>{
      if(response.responseCode==200){
        this.formtab='chngePswrd' 
       this.spinner.hide();
      console.log("admin_verifyOtp==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("admin_verifyOtp_error==>>"+JSON.stringify(err))
    })
  }
  resetPswrd(){
    this.spinner.show();
    if(this.data.newPswrd==this.data.cnfrmPas){
      let dataInfo= {
        "NewPassword":this.data.newPswrd
      }
      this.service.postResponseMethod(dataInfo,"admin_updateAdminPass").subscribe(response=>{
        if(response.responseCode==200){
          this.formtab='login'
         this.spinner.hide();
        console.log("admin_updateAdminPass==>>"+JSON.stringify(response))
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
    }  
    
      },err=>{
        this.spinner.hide();
         alert("Something went wrong!")
        console.log("admin_updateAdminPass_error==>>"+JSON.stringify(err))
      })
    }else{
      alert("Password didn't match")
    }
    }
    
}
