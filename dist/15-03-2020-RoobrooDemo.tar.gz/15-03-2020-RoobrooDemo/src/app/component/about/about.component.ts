import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  aboutTab:any='About';
  myForm: any = FormGroup;
  aboutUs:any=[];
  edit:any={};
  bannerImage:any;
  storyImg:any;
  get_story:any=[];
  updatedStory:any={}
  editstory:any;
  id:any;
  object:any={};
  get_team:any=[];
  editObject:any={};
  updatedTeam:any;
  addTeamImg:any;
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      info: new FormControl('',[Validators.required]),
      story_Title: new FormControl('',[Validators.required]),
      story_desc: new FormControl('',[Validators.required]),
      name: new FormControl('',[Validators.required]),
      teamTitle: new FormControl('',[Validators.required]),
      teamDesc: new FormControl('',[Validators.required]),
      facebook: new FormControl('',[Validators.required]),
      twitter: new FormControl('',[Validators.required]),
      insta: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required]),

})}

  ngOnInit() {
    this.getAbout()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  managetab(val){
    this.aboutTab=val;
  }
  getAbout(){
    this.spinner.show();
    this.service.getResponseMethod("getAbout").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.aboutUs=res.result;
        // this.edit=res.result[0];
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }

  editAbout(val){
    this.edit=val
  }
  update(){
    this.spinner.show();
    this.service.postResponseMethod(this.edit,"updateAbout").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
      console.log("updateAbout==>>"+JSON.stringify(response))
      this.getAbout()
      $("#myModalT").modal("hide");
     } else{
      this.spinner.hide();
       alert("Something went wrong!")
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("updateAbout_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_img(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.bannerImage= event.target.result;
        this.edit.bannerImage=this.bannerImage
        // console.log(this.bannerImage);
      }
    }
  }

  addStory(){
    this.spinner.show();
    let dataInfo= {
      "title":this.myForm.value.story_Title,
      "description":this.myForm.value.story_desc,
      "image":this.storyImg

    }
    this.service.postResponseMethod(dataInfo,"addStory").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
      console.log("addStory==>>"+JSON.stringify(response))
      this.getStory()
      $("#myModalAddStory").modal("hide");
     } else{
      this.spinner.hide();
       alert("Something went wrong!")
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("addStory_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_addStory(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.storyImg = event.target.result;
        // console.log(this.storyImg);
      }
    }
}
getStory(){
  this.spinner.show();
  this.service.getResponseMethod("getStory").subscribe(res=>{
    if(res.responseCode==200){
      this.spinner.hide();
      console.log(JSON.stringify(res));
      this.get_story=res.result;
      // this.updatedStory=res.result[0];
      }
   },
   (err)=>{this.spinner.hide();
    console.log(err)
  });
}
editStory(val){
this.object=val

}
updateStory(){
  this.spinner.show();
  this.service.postResponseMethod(this.object,"editStory").subscribe(response=>{
    console.log("editStory==>>"+JSON.stringify(response))
    if(response.responseCode==200){
      this.spinner.hide();
    // console.log("updateAbout==>>"+JSON.stringify(response))
    this.getStory()
    $("#update").modal("hide");
   } else{
    this.spinner.hide();
     alert("Something went wrong!")
    alert(response.responseMessage);
}

  },err=>{
    this.spinner.hide();
    console.log("editStory_error==>>"+JSON.stringify(err))
  })
}
onSelectFile_editstory(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();

    reader.readAsDataURL(event.target.files[0]);

    reader.onload = (event:any) => {
      this.editstory = event.target.result;
      this.object.image=this.editstory
      // console.log(this.editstory);
    }
  }
}
delStory(){
  this.spinner.show();
  let dataInfo= {
    "id" :this.object._id
}
  this.service.postResponseMethod(dataInfo,"deleteStory").subscribe(response=>{
    if(response.responseCode==200){
     this.spinner.hide();
     console.log("deleteStory==>>"+JSON.stringify(response));
     $("#deleteStory").modal("hide");
     this.getStory()
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
}
  },err=>{
    this.spinner.hide();
    console.log("deleteStory_error==>>"+JSON.stringify(err))
  })
}
cnclDelStory(){
  $("#deleteStory").modal("hide");
}
addTeam(){
    this.spinner.show();
    let dataInfo= {
      "name":this.myForm.value.name,
      "title":this.myForm.value.teamTitle,
      "description":this.myForm.value.teamDesc,
      "profileImage":this.addTeamImg ,
      "facebookLink":this.myForm.value.facebook,
      "twitterLink": this.myForm.value.twitter,
      "instaLink": this.myForm.value.insta,
      "email": this.myForm.value.email

    }
    this.service.postResponseMethod(dataInfo,"addTeam").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
      console.log("addTeam==>>"+JSON.stringify(response))
      this.getTeam()
      $("#feedback").modal("hide");
     } else{
      this.spinner.hide();
       alert("Something went wrong!")
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("addTeam_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_addTeam(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.addTeamImg = event.target.result;
        // console.log(this.editstory);
      }
    }
  }
  getTeam(){
    this.spinner.show();
    this.service.getResponseMethod("getTeam").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.get_team=res.result;
        // this.updatedStory=res.result[0];
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }

  editTeam(val){
    this.editObject=val;
  }
  updateTeam(){
    this.spinner.show();
    this.service.postResponseMethod(this.editObject,"editTeam").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
        console.log("editTeam==>>"+JSON.stringify(response))
      this.getTeam()
      $("#editModal").modal("hide");
     } else{
      this.spinner.hide();
       alert("Something went wrong!")
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("editTeam_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_updatedTeam(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.updatedTeam = event.target.result;
        this.editObject.profileImage=this.updatedTeam
        // console.log(this.editstory);
      }
    }
  }
  delTeam(){
    this.spinner.show();
    let dataInfo= {
      "id" :this.editObject._id
  }
    this.service.postResponseMethod(dataInfo,"deleteTeam").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       console.log("deleteTeam==>>"+JSON.stringify(response));
       $("#deleteTeam").modal("hide");
       this.getTeam()
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
  }
    },err=>{
      this.spinner.hide();
      console.log("deleteTeam_error==>>"+JSON.stringify(err))
    })
  }
  cnclDelTeam(){
    $("#deleteTeam").modal("hide");
  }
}
