import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl, FormBuilder, FormArray } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import { DatePipe } from '@angular/common'
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

declare var $: any;
@Component({
  selector: 'app-histri',
  templateUrl: './histri.component.html',
  styleUrls: ['./histri.component.css']
})
export class HistriComponent implements OnInit {
  offeringTab: any = 'AddBanner';
  myForm: any = FormGroup;
  submitted = false;
  myFormEdit: any = FormGroup;
  banners: any = [];
  edit: any = {};
  bnrUrl: any;
  eventUrl: any;
  imageErr: any;
  blogs: any = [];
  blogObject: any = {};
  upEventImg: any;
  data: any = {};
  events: any = [];
  public Editor = ClassicEditor;
  constructor(private router: Router, private spinner: NgxSpinnerService, private service: RestDataService, private _formBuilder: FormBuilder, public datepipe: DatePipe) {
    this.myForm = this._formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
    })
    this.myFormEdit = this._formBuilder.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
    })
  }
  editEvent(val) {
    this.blogObject = val;
  }
  ngOnInit() {
    this.getBanr()
    this.imageErr = false;
  }
  dashboard() {
    this.router.navigate(['dashboard'])
  }
  managetab(val) {
    this.offeringTab = val;
  }
  getBanr() {
    this.spinner.show();
    this.service.getResponseMethod("getbannerhistory").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        this.banners = res.result;
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  editBnr(val) {
    this.edit = val
  }
  updateBnr() {
    // this.spinner.show();
    console.log('updateBnr', this.edit);
    this.service.postResponseMethod(this.edit, "updatebannerhistory").subscribe(response => {
      if (response.responseCode == 200) {
        this.getBanr()
        this.spinner.hide();
        $("#myModal33").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!")
    })
  }
  onSelectFile_bnr(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.bnrUrl = event.target.result;
        this.edit.bannerImage = this.bnrUrl
      }
    }
  }
  removeErr() {
    this.submitted = false;
    this.imageErr = false;
  }
  get f() { return this.myForm.controls; }
  addOffering() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.eventUrl == undefined) {
      this.imageErr = true;
      return;
    }
    if (this.myForm.invalid) {
      return;
    }
    let dataInfo = {
      "image": this.eventUrl,
      "title": this.myForm.value.title,
      "description": this.myForm.value.description,
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo, "addhistorycard").subscribe(response => {
      if (response.responseCode == 200) {
        this.getOffering()
        this.spinner.hide();
        $("#myModalAddOffering").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!")
    })
  }
  onSelectFile_blogImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.eventUrl = event.target.result;
        this.imageErr = false;
      }
    }
  }
  getOffering() {
    this.spinner.show();
    this.service.getResponseMethod("getbannerhistory").subscribe(res => {
      if (res.responseCode == 200) {
        this.spinner.hide();
        if (res.result.length > 0) {
          this.events = res.result[0].cards;
        }
        else {
          this.events = [];
        }
      }
    },
      (err) => {
        this.spinner.hide();
      });
  }
  updateOffering() {
    // this.spinner.show();
    this.service.postResponseMethod(this.blogObject, "edithistorycard").subscribe(response => {
      if (response.responseCode == 200) {
        this.getOffering()
        this.spinner.hide();
        $("#myModalEdit").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
      alert("Something went wrong!");
    })
  }
  onSelectFile_editblogImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event: any) => {
        this.upEventImg = event.target.result;
        this.blogObject.image = this.upEventImg
      }
    }
  }
  delEvent() {
    let dataInfo = {
      "id": this.blogObject._id
    }
    // this.spinner.show();
    this.service.postResponseMethod(dataInfo, "deletehistorycard").subscribe(response => {
      if (response.responseCode == 200) {
        this.getOffering()
        this.spinner.hide();
        $("#delete").modal("hide");
      } else {
        this.spinner.hide();
        alert(response.responseMessage);
      }
    }, err => {
      this.spinner.hide();
    })
  }
  cnclDelEvent() {
    $("#delete").modal("hide");
  }

}
