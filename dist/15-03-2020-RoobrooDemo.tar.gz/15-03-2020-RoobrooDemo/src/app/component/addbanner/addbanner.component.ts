import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-addbanner',
  templateUrl: './addbanner.component.html',
  styleUrls: ['./addbanner.component.css']
})
export class AddbannerComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  banners:any=[];
  object:any={};
  edit:any={};
  actionType:any={};
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),

})
  }

  ngOnInit() {
   this.getBanr()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  getBanr(){
    this.spinner.show();
    this.service.getResponseMethod("get_bannr").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      console.log(JSON.stringify(res));
      this.banners=res.data[0].homeBanner;
      }
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    });
  }
  editData(val){
    this.object=val
    this.edit.title=this.object.banrTitle
    this.edit.desc=this.object.banrDescrptn
    this.imgUrl=this.object.banrImgs
    this.edit.id=this.object._id
  }
  update(){
    this.spinner.show();
    let dataInfo= {
      "bannerId":this.edit.id,
      "banrTitle" :this.edit.title,
      "banrDescrptn" :this.edit.desc,
      "banrImgs" :  this.imgUrl
    }
    this.service.postResponseMethod(dataInfo,"edit_bannr").subscribe(response=>{
      if(response.responseCode==200){
       this.getBanr()
       this.spinner.hide();
       $("#edit").modal("hide");
      console.log("edit_bannr==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("edit_bannr_error==>>"+JSON.stringify(err))
    })
  }
  delete(val){
    this.object=val
    this.edit.id=this.object._id
  }
  cnfrmDel(){
    this.spinner.show();
    let dataInfo= {
      "bannerId" : this.edit.id

    }
    this.service.postResponseMethod(dataInfo,"delete_bannr").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       console.log("delete_bannr==>>"+JSON.stringify(response));
       $("#delete").modal("hide");
       this.getBanr()
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
  }
    },err=>{
      this.spinner.hide();
      console.log("delete_bannr_error==>>"+JSON.stringify(err))
    })
  }
  cnclDel(){
   $("#delete").modal("hide");
  }
  savebnr(){
    this.spinner.show();
    let dataInfo= {
      "banrTitle" :this.myForm.value.title,
      "banrDescrptn" :this.myForm.value.desc,
      "banrImgs" :  this.imgUrl
    }
    this.service.postResponseMethod(dataInfo,"add_banr").subscribe(response=>{
      if(response.responseCode==200){
       this.getBanr()
       this.spinner.hide();
       $("#myModal").modal("hide");
       this.actionType='modal'
      console.log("add_banr==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("add_banr_error==>>"+JSON.stringify(err))
    })
    }
    onSelectFile_img(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          console.log(this.imgUrl);
        }
      }
  }
}
