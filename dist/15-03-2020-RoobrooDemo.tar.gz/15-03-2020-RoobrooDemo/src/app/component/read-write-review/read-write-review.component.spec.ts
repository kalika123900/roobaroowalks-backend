import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadWriteReviewComponent } from './read-write-review.component';

describe('ReadWriteReviewComponent', () => {
  let component: ReadWriteReviewComponent;
  let fixture: ComponentFixture<ReadWriteReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadWriteReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadWriteReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
