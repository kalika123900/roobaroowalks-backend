import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router} from '@angular/router';

@Component({
  selector: 'app-read-write-review',
  templateUrl: './read-write-review.component.html',
  styleUrls: ['./read-write-review.component.css']
})
export class ReadWriteReviewComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  link:any=[];
  constructor(private service: RestDataService,private router: Router) { 
    this.myForm = new FormGroup({
      readLink: new FormControl('',[Validators.required]),
      writeLink: new FormControl('',[Validators.required]),
    
}) }
  ngOnInit() {
    this.service.getResponseMethod("get_readWrite").subscribe(res=>{
      console.log(JSON.stringify(res)); 
      this.link=res.data[0].readWriteRvw;
     },
     (err)=>{console.log(err)
    });
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  save(){
    // alert("ok")
    let dataInfo= {
      "readLnk":this.myForm.value.readLink,
      "writeLnk":this.myForm.value.writeLink
  
    }
    this.service.postResponseMethod(dataInfo,"read_write").subscribe(response=>{
      if(response.responseCode==200){
      console.log("read_write==>>"+JSON.stringify(response))
     } else{
      alert(response.responseMessage);
  }  
  
    },err=>{
      console.log("read_write_error==>>"+JSON.stringify(err))
    })
    }
    
}