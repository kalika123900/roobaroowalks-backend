import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  adminData:any={}
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) { }

  ngOnInit() {
    this.getProfile()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  logOut(){
    this.router.navigate(['login'])
    localStorage.setItem("loginStatus",'')
  }
  getProfile(){
      this.spinner.show();
      this.service.getResponseMethod("admin_getProfile").subscribe(res=>{
        if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.adminData=res.profile[0];
        }
       },
       (err)=>{
        this.spinner.hide();
        console.log(err)
      });
    }
  editprofile(){
    this.spinner.show();
    this.service.postResponseMethod(this.adminData,"admin_editProfile").subscribe(response=>{
      if(response.responseCode==200){
        $("#myModal").modal("hide");
       this.spinner.hide();
      console.log("admin_editProfile==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("admin_editProfile_error==>>"+JSON.stringify(err))
    })
  }
}



// import { Component, OnInit } from '@angular/core';
// import { Router} from '@angular/router';
// @Component({
//   selector: 'app-header',
//   templateUrl: './header.component.html',
//   styleUrls: ['./header.component.css']
// })
// export class HeaderComponent implements OnInit {

//   constructor(private router: Router) { }

//   ngOnInit() {
//   }
//   dashboard(){
//     this.router.navigate(['dashboard'])
//   }
// }
