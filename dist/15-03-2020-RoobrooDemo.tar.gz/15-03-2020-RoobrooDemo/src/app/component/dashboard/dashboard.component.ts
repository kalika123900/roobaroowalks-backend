import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  city_management(){
    this.router.navigate(['city-mngmnt'])
  }
  home(){
      this.router.navigate(['home'])
    }
  booking(){
    this.router.navigate(['booking'])
  }
  blog(){
    this.router.navigate(['blog'])
  }
  events(){
    this.router.navigate(['events'])
  }
  culture(){
    this.router.navigate(['culture'])
  }
  about(){
    this.router.navigate(['about'])

  }
  career(){
    this.router.navigate(['career'])

  }
  contact(){
    this.router.navigate(['contact'])

  }
}