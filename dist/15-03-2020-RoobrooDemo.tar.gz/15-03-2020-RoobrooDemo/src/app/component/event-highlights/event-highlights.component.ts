import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
declare var $:any;
@Component({
  selector: 'app-event-highlights',
  templateUrl: './event-highlights.component.html',
  styleUrls: ['./event-highlights.component.css']
})
export class EventHighlightsComponent implements OnInit {
  myForm: any = FormGroup;
  submitted = false;
  imageErr:any;
  highlights:any=[];
  imgUrl:any;
  imgArray:any=[];
  blogObj:any={}
  index:any;
  upImgUrl:any;
  info:any={}
  obj:any={}
  blogDesc:any={}
  cityList:any=[];
  public Editor = ClassicEditor;
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      /* city: new FormControl('',[Validators.required]),*/
      blog: new FormControl('',[Validators.required]),
      imgTitle: new FormControl('',[Validators.required]),
      imgDescription: new FormControl('',[Validators.required]),
    })
   }

  ngOnInit() {
    this.getEvent();
    this.getCity();
    this.imageErr=false;
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  events_page(){
    this.router.navigate(['events'])
  }
  getCity(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        this.cityList=res.cityList
        }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
  getEvent(){
    this.spinner.show();
    this.service.getResponseMethod("getbannerEvent").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      //this.highlights=res.result.addBlog;
      this.highlights = res.result[0].addEvent;
      }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
  onSelectFile_img(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.imgUrl= event.target.result;
        this.imageErr=false;
      }
    }
  }
  removeErr(){
    this.submitted = false;
    this.imageErr=false;
  }
  get highlightErr() { return this.myForm.controls; }
  addHighlights(){
    this.submitted = true;
    // stop here if form is invalid
    if(this.imgUrl == undefined){
      this.imageErr = true;
      return;
    }
    if (this.myForm.invalid) {
        return;
    }
    let dataInfo= {
     "id":this.myForm.value.blog,
     "images":this.imgUrl,
     "imgTitle":this.myForm.value.imgTitle,
     "imgDescription":this.myForm.value.imgDescription
       }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"addEventHighlights").subscribe(response=>{
          if(response.responseCode==200){
            this.spinner.hide();
            this.getEvent()
            $("#feedback").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
        })
  }
  highlightsData(){
    return this.highlights.filter((item)=>item.highlights.length!=0);
  }
  editMoreImg(val){
    this.blogObj=val;
    this.imgArray=this.blogObj.highlights
    this.info.blogTitle=this.blogObj.title
    this.info.desc=this.blogObj.highlights.imgDescription
  }
  remImg(val){
    this.index=val
    if(this.index != -1) {
      this.imgArray.splice(this.index, 1);
    }
  }
 editDesc(val,desc){
 this.obj=val;
 this.blogDesc=desc;
 }
  updateImg(){
   // this.spinner.show();
    let dataInfo= {
      "id":this.blogObj._id,
      "highlights":this.imgArray
    }
      this.service.postResponseMethod(dataInfo,"editEventHighlights").subscribe(response=>{
          if(response.responseCode==200){
          this.spinner.hide();
          this.getEvent()
          $("#feedbackEdit").modal("hide");
          } else{
          this.spinner.hide();
          alert(response.responseMessage);
       }
         },err=>{
          this.spinner.hide();
          alert("Something went wrong!")
         })
  }
}
