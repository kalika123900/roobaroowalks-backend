import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CityMngmntComponent } from './city-mngmnt.component';

describe('CityMngmntComponent', () => {
  let component: CityMngmntComponent;
  let fixture: ComponentFixture<CityMngmntComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CityMngmntComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CityMngmntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
