import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-city-mngmnt',
  templateUrl: './city-mngmnt.component.html',
  styleUrls: ['./city-mngmnt.component.css']
})
export class CityMngmntComponent implements OnInit {
  myForm: any = FormGroup;
  cityDetails:any=[]
  imgUrl_1:any;
  imgUrl_2:any;
  imgUrl_3:any;
  imgUrl_4:any;
  imgUrl_city:any;
  imgUrl_bnr:any;
  cityList:any={};
  edit:any={};
  cityMngmnt:any='AddCity';
  coverUrl:any;
  walks:any=[];
  imgUrl_mob:any;
  walkid:any;
  walkObject:any={}
  upWalkUrl:any;
  data:any={};
  upImgUrl_mob:any;
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      cityName: new FormControl('',[Validators.required]),
      citySlug: new FormControl('',[Validators.required]),
      ctyVideo: new FormControl('',[Validators.required]),
      comSoon: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      title_1: new FormControl('',[Validators.required]),
      des_1: new FormControl('',[Validators.required]),
      title_2: new FormControl('',[Validators.required]),
      desc_2: new FormControl('',[Validators.required]),
      title_3: new FormControl('',[Validators.required]),
      desc_3: new FormControl('',[Validators.required]),
      title_4: new FormControl('',[Validators.required]),
      desc_4: new FormControl('',[Validators.required]),
      mobTitle:new FormControl('',[Validators.required]),
      mob_desc:new FormControl('',[Validators.required]),
      mobLink:new FormControl('',[Validators.required,Validators.pattern(/(http[s]?:\/\/)?[^\s(["<,>]*\.[^\s[",><]*/)]),


      name: new FormControl('',[Validators.required]),
      walkName: new FormControl('',[Validators.required]),
      price: new FormControl('',[Validators.required]),
      privatePrice: new FormControl('',[Validators.required]),
      shrtDesc: new FormControl('',[Validators.required]),
      details: new FormControl('',[Validators.required]),
      walkVideo: new FormControl('',[Validators.required]),
      highlights: new FormControl('',[Validators.required]),
      desc_exp: new FormControl('',[Validators.required]),
      fullDesc: new FormControl('',[Validators.required]),
      desc_incl: new FormControl('',[Validators.required]),
      descKnow: new FormControl('',[Validators.required]),
      category:new FormControl('',[Validators.required]),
      walkTime:new FormControl('',[Validators.required]),
      duration:new FormControl('',[Validators.required]),
      slot:new FormControl('',[Validators.required]),
      minSlot:new FormControl('',[Validators.required]),

})
   }

  ngOnInit() {
    this.getCityList()
  }
  managetab(val){
this.cityMngmnt=val;
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  city_more_images(){
    this.router.navigate(['city-more-img'])
  }
  client_feedback(){
    this.router.navigate(['client-feedback'])
  }
  getWalks(){
    let dataInfo= {
      // "Page":"1",
      // "Select":"_id walkName cityName",
      // "Limit":"2"
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"get_Walks").subscribe(response=>{
          if(response.responseCode==200){
            this.walks=response.result

            // this.getWalks()
            this.spinner.hide();
            // $("#myModal22").modal("hide");
          console.log("get_Walks==>>"+JSON.stringify(response))
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }

        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("get_Walks_error==>>"+JSON.stringify(err))
        })
  }
  getCityList(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  addDetails(){
    let dataInfo= {
  "ctyName" :this.myForm.value.cityName,
  "slug"  : this.myForm.value.slug,
  "ctyStatus" :this.myForm.value.comSoon,
  "ctyImgs" : this.imgUrl_city,
  "ctyVideo" : this.myForm.value.ctyVideo,
  "ctyTitle" :this.myForm.value.title,
  "ctyDiscription":this.myForm.value.desc,
  "ctyBanner":this.imgUrl_bnr,
  "appTitle":this.myForm.value.mobTitle ,
  "appDesc":this.myForm.value.mob_desc ,
  "appLink":this.myForm.value.mobLink ,
  "appImage":this.imgUrl_mob,
  "keyPoint": [{
               "keyTle":this.myForm.value.title_1,
               "keyDesc":this.myForm.value.des_1,
               "keyImgs":this.imgUrl_1
              },{
               "keyTle":this.myForm.value.title_2,
               "keyDesc":this.myForm.value.desc_2,
               "keyImgs":this.imgUrl_2
              },{
               "keyTle":this.myForm.value.title_3,
               "keyDesc":this.myForm.value.desc_3,
               "keyImgs":this.imgUrl_3
              },{
                "keyTle":this.myForm.value.title_4,
               "keyDesc":this.myForm.value.desc_4,
               "keyImgs":this.imgUrl_4
              }]
    }
   /*  console.log(dataInfo);
    return false; */
   this.spinner.show();
    this.service.postResponseMethod(dataInfo,"add_city").subscribe(response=>{
      if(response.responseCode==200){
        this.getCityList()
        this.spinner.hide();
        $("#myModal").modal("hide");
      console.log("add_city==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("add_city_error==>>"+JSON.stringify(err))
    })
    }
editData(val){
this.cityList=val
console.log(JSON.stringify(this.cityList))
this.edit.cityName=this.cityList.ctyName
this.edit.ctyStatus=this.cityList.ctyStatus
this.imgUrl_city=this.cityList.ctyImgs
this.edit.ctyTitle=this.cityList.ctyTitle
this.edit.ctyDes=this.cityList.ctyDiscription
this.imgUrl_bnr=this.cityList.ctyBanner
this.edit.mobTtl=this.cityList.appTitle
this.edit.mobDes=this.cityList.appDesc
this.edit.mobLnk=this.cityList.appLink
this.edit.Key1Ttl=this.cityList.keyPoint[0].keyTle
this.edit.Key1des=this.cityList.keyPoint[0].keyDesc
this.imgUrl_1=this.cityList.keyPoint[0].keyImgs
this.edit.Key2Ttl=this.cityList.keyPoint[1].keyTle
this.edit.Key2des=this.cityList.keyPoint[1].keyDesc
this.imgUrl_2=this.cityList.keyPoint[1].keyImgs
this.edit.Key3Ttl=this.cityList.keyPoint[2].keyTle
this.edit.Key3des=this.cityList.keyPoint[2].keyDesc
this.imgUrl_3=this.cityList.keyPoint[2].keyImgs
this.edit.Key4Ttl=this.cityList.keyPoint[3].keyTle
this.edit.Key4des=this.cityList.keyPoint[3].keyDesc
this.imgUrl_4=this.cityList.keyPoint[3].keyImgs
this.imgUrl_mob=this.cityList.appImage
this.edit.slug=this.cityList.slug

    }
update(){
      let dataInfo= {
        "_id" :this.cityList._id,
        "ctyName" :this.edit.cityName,
        "ctyVideo" :this.edit.ctyVideo,
        "slug" : this.edit.slug,
        "ctyStatus" : this.edit.ctyStatus,
        "ctyImgs" :this.imgUrl_city,
        "ctyTitle" :this.edit.ctyTitle,
        "ctyDiscription":this.edit.ctyDes,
        "ctyBanner":this.imgUrl_bnr,
        "appImage":this.imgUrl_mob,
        "keyPoint": [{
                     "keyTle":this.edit.Key1Ttl,
                     "keyDesc":this.edit.Key1des,
                     "keyImgs":this.imgUrl_1
                    },{
                     "keyTle":this.edit.Key2Ttl,
                     "keyDesc":this.edit.Key2des,
                     "keyImgs":this.imgUrl_2
                    },{
                     "keyTle":this.edit.Key3Ttl,
                     "keyDesc":this.edit.Key3des,
                     "keyImgs":this.imgUrl_3
                    },{
                      "keyTle":this.edit.Key4Ttl,
                      "keyDesc":this.edit.Key4des,
                      "keyImgs":this.imgUrl_4
                     }]

          }
          this.spinner.show();
          this.service.postResponseMethod(dataInfo,"edit_city").subscribe(response=>{
            if(response.responseCode==200){
              this.getCityList()
              this.spinner.hide();
              $("#editModal").modal("hide");
            console.log("edit_city==>>"+JSON.stringify(response))
           } else{
            this.spinner.hide();
            alert(response.responseMessage);
        }

          },err=>{
            this.spinner.hide();
            alert("Something went wrong!")
            console.log("edit_city_error==>>"+JSON.stringify(err))
          })
    }
delete(val){
      this.cityList=val
      this.edit.id=this.cityList._id

    }
    cnfrmDel(){
      // alert("ok")
      let dataInfo= {
        "cityId" :this.edit.id

      }
      this.spinner.show();
      this.service.postResponseMethod(dataInfo,"delete_city").subscribe(response=>{
        if(response.responseCode==200){
        console.log("delete_city==>>"+JSON.stringify(response))
        this.getCityList()
        this.spinner.hide();
        $("#deleteCity").modal("hide");
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
    }

      },err=>{
        this.spinner.hide();
        console.log("delete_city_error==>>"+JSON.stringify(err))
      })
    }
    cnclDel(){
      $("#deleteCity").modal("hide");
    }
    city_feedback(){
      this.router.navigate(['city-feedback'])
    }
    onSelectFile_img_1(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_1 = event.target.result;
          //console.log(this.imgUrl_1);
        }
      }
    }
    onSelectFile_img_2(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_2 = event.target.result;
         // console.log(this.imgUrl_2);
        }
      }
    }
    onSelectFile_img_3(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_3 = event.target.result;
         // console.log(this.imgUrl_3);
        }
      }
    }
    onSelectFile_img_4(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_4 = event.target.result;
          //console.log(this.imgUrl_4);
        }
      }
    }
    onSelectFile_img_city(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_city = event.target.result;
         // console.log(this.imgUrl_city);
        }
      }
    }
    onSelectFile_img_bnr(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_bnr = event.target.result;
         // console.log(this.imgUrl_bnr);
        }
      }
    }
    onSelectFile_img(event){
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.imgUrl_mob = event.target.result;
         // console.log(this.imgUrl_mob);
        }
      }
    }

    addWalk(){
      let dataInfo= {
        "cityId":this.myForm.value.name.split('@')[0],
        "cityName":this.myForm.value.name.split('@')[1],
        "walkName":this.myForm.value.walkName,
        "walkCategory":this.myForm.value.category,
        "groupPrice":this.myForm.value.price,
        "privategroupPrice":this.myForm.value.privatePrice,
        "shortDesc":this.myForm.value.shrtDesc,
        "detailsonPage":this.myForm.value.details,
        "walkVideo":this.myForm.value.walkVideo,
        "coverImage": this.coverUrl,
        "expHighlight":this.myForm.value.highlights,
        "expDesc":this.myForm.value.desc_exp,
        "includesDesc":this.myForm.value.desc_incl,
        "fullDesc":this.myForm.value.fullDesc,
        "knowbeforeyougoDesc":this.myForm.value.descKnow,
        "walkTime":this.myForm.value.walkTime,
        "walkDuration":this.myForm.value.duration,
        "totalSlot":this.myForm.value.slot,
        "minimumbookingRequire":this.myForm.value.minSlot,
          }
          this.spinner.show();
          this.service.postResponseMethod(dataInfo,"addWalks").subscribe(response=>{
            if(response.responseCode==200){
              this.getWalks()
              this.spinner.hide();
              $("#myModal22").modal("hide");
           // console.log("addWalks==>>"+JSON.stringify(response))
           } else{
            this.spinner.hide();
            alert(response.responseMessage);
        }

          },err=>{
            this.spinner.hide();
             alert("Something went wrong!")
            //console.log("addWalks_error==>>"+JSON.stringify(err))
          })
    }
    onSelectFile_coverImg(event){
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        reader.onload = (event:any) => {
          this.coverUrl = event.target.result;
          //console.log(this.coverUrl);
        }
      }
    }
    editWalk(val){
      this.walkObject=val
    }
    updateWalk(){
      this.walkObject.cityId=this.walkObject.city.split('@')[0],
      this.walkObject.cityName=this.walkObject.city.split('@')[1],
      this.walkObject.city=this.walkObject.cityId+"@"+this.walkObject.cityName
          this.spinner.show();
          this.service.postResponseMethod(this.walkObject,"editWalks").subscribe(response=>{
            if(response.responseCode==200){
              this.getWalks()
              this.spinner.hide();
              $("#myModalEdit").modal("hide");
           // console.log("editWalks==>>"+JSON.stringify(response))
           } else{
            this.spinner.hide();
            alert(response.responseMessage);
        }

          },err=>{
            this.spinner.hide();
            alert("Something went wrong!")
            //console.log("editWalks_error==>>"+JSON.stringify(err))
          })
    }
    onSelectFile_upWalkImg(event){
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.upWalkUrl = event.target.result;
          this.walkObject.coverImage=this.upWalkUrl
          // console.log(this.upWalkUrl);
        }
      }
    }
    delWalk(){
      let dataInfo= {
        "id":this.walkObject._id
      }
      this.spinner.show();
      this.service.postResponseMethod(dataInfo,"deleteWalks").subscribe(response=>{
        if(response.responseCode==200){
        console.log("deleteWalks==>>"+JSON.stringify(response))
        this.getWalks()
        this.spinner.hide();
        $("#deleteWalk").modal("hide");
       } else{
        this.spinner.hide();
        alert(response.responseMessage);
    }

      },err=>{
        this.spinner.hide();
        console.log("deleteWalks_error==>>"+JSON.stringify(err))
      })
    }
    cnclDelWalk(){
      $("#deleteWalk").modal("hide");
    }
    searchWalk(){
      let dataInfo= {
        "srchWlkNme" :this.data.search
      }
      this.service.postResponseMethod(dataInfo,"search_walk").subscribe(response=>{
        if(response.responseCode==200){
            this.walks=response.data
        console.log("search_walk==>>"+JSON.stringify(response))
       } else{
        alert(response.responseMessage);
      }

      },err=>{
        console.log("search_walk_error==>>"+JSON.stringify(err))
      })
      }
      searchCity(){
        let dataInfo= {
          "srchCty" :this.data.srchCity
        }
        this.service.postResponseMethod(dataInfo,"search_addCity").subscribe(response=>{
          if(response.responseCode==200){
              this.cityDetails=response.data
          console.log("search_addCity==>>"+JSON.stringify(response))
         } else{
          alert(response.responseMessage);
        }

        },err=>{
          console.log("search_addCity_error==>>"+JSON.stringify(err))
        })
      }
}
