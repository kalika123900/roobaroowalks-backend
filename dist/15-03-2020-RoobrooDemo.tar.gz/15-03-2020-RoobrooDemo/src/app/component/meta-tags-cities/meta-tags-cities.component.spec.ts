import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetaTagsCitiesComponent } from './meta-tags-cities.component';

describe('MetaTagsCitiesComponent', () => {
  let component: MetaTagsCitiesComponent;
  let fixture: ComponentFixture<MetaTagsCitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetaTagsCitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetaTagsCitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
