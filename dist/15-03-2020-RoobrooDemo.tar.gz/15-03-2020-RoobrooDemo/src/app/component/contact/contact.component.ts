import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  myForm: any = FormGroup;
  result:any={};
  contactList:any=[];
  object:any={}
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) {
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      address: new FormControl('',[Validators.required]),
      phone: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required]),
      website: new FormControl('',[Validators.required]),
      facebook: new FormControl('',[Validators.required]),
      twitter: new FormControl('',[Validators.required]),
      insta: new FormControl('',[Validators.required]),
      days: new FormControl('',[Validators.required]),
      time: new FormControl('',[Validators.required]),

    })
  }
  ngOnInit() {
    this.getContact()
  }
  getContact(){
    this.spinner.show();
    this.service.getResponseMethod("getcontactDetail").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.contactList=res.result;
        this.result=this.contactList[0]
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }


  dashboard(){
    this.router.navigate(['dashboard'])
  }
  editContact(val){
    this.object=val
  }
    update(){
      this.spinner.show();
      this.object.address=this.object.address+"@"+this.object.lattitude+"@"+this.object.longitude
      this.service.postResponseMethod(this.object,"editContact").subscribe(response=>{
        if(response.responseCode==200){
        //  this.getBanr()
          this.spinner.hide();
          $("#myModal").modal("hide");
        //  this.actionType='modal'
          console.log("editContact==>>"+JSON.stringify(response))
        } else{
          this.spinner.hide();
          alert(response.responseMessage);
        }

      },err=>{
        this.spinner.hide();
         alert("Something went wrong!")
        console.log("editContact_error==>>"+JSON.stringify(err))
      })
    }
  ourOffice(){
    this.router.navigate(['our-office'])

  }

}
