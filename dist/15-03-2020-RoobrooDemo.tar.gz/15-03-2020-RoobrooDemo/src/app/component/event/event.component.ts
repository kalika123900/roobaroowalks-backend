import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl,FormBuilder ,FormArray} from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';
import { DatePipe } from '@angular/common'
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AngularEditorConfig } from '@kolkov/angular-editor';
declare var $:any;
@Component({
  selector: 'app-blog',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '10rem',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    sanitize: true,
    toolbarPosition: 'top',
  };
  eventTab:any='AddBanner';
  myForm: any = FormGroup;
  submitted = false;
  myFormEdit: any = FormGroup;
  banners:any=[];
  highlight:Array<any>=[];
  edit:any={};
  bnrUrl:any;
  eventUrl:any;
  eventVerticalImg:any;
  imageErr:any;
  verticalErr:any
  profileImg:any;
  blogs:any=[];
  initItemItineraryEditValue:any=[];
  blogObject:any={};
  Up_profileImg:any;
  upEventImg:any;
  upVerEventImg:any;
  data:any={};
  events:any=[];
  tagList:any=[];
  tagArray:any=[];
  itinerary:any=[];
  index:any;
  categoryList:any=[];
  cityList:any=[];
  editTags:any=[]
  public Editor = ClassicEditor;
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService,private _formBuilder: FormBuilder,public datepipe: DatePipe) {
      this.myForm = this._formBuilder.group({
        title: ['',Validators.required],
        slug: ['',Validators.required],
        shortDes: ['',Validators.required],
        description: ['',Validators.required],
        startDate: ['',Validators.required],
        endDate: ['',Validators.required],
        city: ['',Validators.required],
        itinerary: this._formBuilder.array([this.initItemItinerary()]),
        pricedescription: ['',Validators.required],
        pricebase: ['',Validators.required],
        pricewithaccomodation: ['',Validators.required],
  })
  this.myFormEdit = this._formBuilder.group({
    title: ['',Validators.required],
    slug: ['',Validators.required],
    ShortDesc: ['',Validators.required],
    description: ['',Validators.required],
    startDate: ['',Validators.required],
    endDate: ['',Validators.required],
    city: ['',Validators.required],
    itinerary: this._formBuilder.array([this.initItemItineraryEdit()]),
    pricedescription: ['',Validators.required],
    pricebase: ['',Validators.required],
    pricewithaccomodation: ['',Validators.required],
  })
}

initItemItineraryEdit() {
  return this._formBuilder.group({
    itiTitle: [''],
    itiDescription: [''],
  });
}
addNewItineraryEdit() {
  this.formArrItineraryEdit.push(this.initItemItineraryEdit());
}
get formArrItineraryEdit() {
  return this.myFormEdit.get('itinerary') as FormArray;
}
deleteItineraryEdit(index: number) {
  this.formArrItineraryEdit.removeAt(index);
}
editEvent(val){
  var _that = this;
  this.blogObject=val;
  while (_that.formArrItineraryEdit.length !== 0) {
    _that.formArrItineraryEdit.removeAt(0)
  }
  this.editTags=this.blogObject.tags;
  this.blogObject.itinerary.map(function(value,index){
    let valueObject = _that._formBuilder.group({
      itiTitle: [value.itiTitle],
      itiDescription: [value.itiDescription],
    });
    _that.formArrItineraryEdit.push(valueObject);
  })
}
  initItemItinerary() {
    return this._formBuilder.group({
      itiTitle: ['',Validators.required],
      itiDescription: ['',Validators.required],
    });
  }
  addNewItinerary() {
    this.formArrItinerary.push(this.initItemItinerary());
  }
  get formArrItinerary() {
    return this.myForm.get('itinerary') as FormArray;
  }
  deleteItinerary(index: number) {
    this.formArrItinerary.removeAt(index);
  }
  onSelectFile_highlight(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.highlight.push(event.target.result);
      }
    }
  }
  ngOnInit() {
    this.getBanr()
    this.getTag()
    this.getCategory()
    this.getCity()
    this.imageErr=false;
    this.verticalErr=false;
  }
  numberValidation(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  tags(){
  this.router.navigate(['tags'])
  }
  managetab(val){
    this.eventTab=val;
  }
  add_highlights(){
    this.router.navigate(['event-highlights'])
  }
  more_images(){
    this.router.navigate(['event-more-img'])
  }
  instaImages(){
    this.router.navigate(['blog-insta-img'])
  }
  getBanr(){
    this.spinner.show();
    this.service.getResponseMethod("getbannerEvent").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      this.banners=res.result;
      }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
  editBnr(val){
    this.edit=val
  }
  updateBnr(){
    //this.spinner.show();
    this.service.postResponseMethod(this.edit,"updatebannerEvent").subscribe(response=>{
      if(response.responseCode==200){
       this.getBanr()
       this.spinner.hide();
       $("#myModal33").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
    }
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
    })
  }
  onSelectFile_bnr(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.bnrUrl = event.target.result;
        this.edit.image=this.bnrUrl
      }
    }
}
removeErr(){
  this.submitted = false;
  this.imageErr=false;
  this.verticalErr=false;
}
get f() { return this.myForm.controls; }
addBlog(){
   this.submitted = true;
    // stop here if form is invalid
    if(this.eventUrl == undefined){
      this.imageErr = true;
      return;
    }
    if(this.eventVerticalImg == undefined){
      this.verticalErr = true;
      return;
    }
    if (this.myForm.invalid) {
        return;
    }
  let latest_start_date = this.datepipe.transform(this.myForm.value.startDate, 'dd/MM/yyyy');
  let latest_end_date = this.datepipe.transform(this.myForm.value.endDate, 'dd/MM/yyyy');
  let dataInfo= {
    "title":this.myForm.value.title,
    "slug":this.myForm.value.slug,
    "ShortDesc":this.myForm.value.shortDes,
    "description":this.myForm.value.description,
    "image":this.eventUrl,
    "verticalImage":this.eventVerticalImg,
    "startDate":latest_start_date,
    "endDate":latest_end_date,
    "cityId":this.myForm.value.city,
    "itinerary":this.myForm.value.itinerary,
    "pricedescription":this.myForm.value.pricedescription,
    "pricebase":this.myForm.value.pricebase,
    "pricewithaccomodation":this.myForm.value.pricewithaccomodation,
    "eventBannerType": 'image',
   }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"addEvent").subscribe(response=>{
    if(response.responseCode==200){
    this.getEvent()
     this.spinner.hide();
     $("#myModalAddEvent").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
  }
  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
  })
  }
  onSelectFile_blogImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.eventUrl = event.target.result;
        this.imageErr= false;
      }
    }
}
onSelectFile_verticalImg(event) {
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.eventVerticalImg = event.target.result;
      this.verticalErr= false;
    }
  }
}
onSelectFile_authImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.profileImg = event.target.result;
    }
  }
}
getEvent(){
  this.spinner.show();
  this.service.getResponseMethod("getbannerEvent").subscribe(res=>{
    if(res.responseCode==200){
    this.spinner.hide();
    if(res.result.length>0)
    {
      this.events=res.result[0].addEvent;
    }
    else
    {
      this.events=[];
    }
    }
   },
   (err)=>{
    this.spinner.hide();
  });
}
updateEvent(){
  this.spinner.show();
  this.blogObject.tags = this.editTags;
  if(Object.prototype.toString.call(this.myFormEdit.value.startDate) === '[object Date]'){
    this.blogObject.startDate = this.datepipe.transform(this.myFormEdit.value.startDate, 'dd/MM/yyyy');
  }
  else
  {
    this.blogObject.startDate = this.myFormEdit.value.startDate
  }
  if(Object.prototype.toString.call(this.myFormEdit.value.endDate) === '[object Date]'){
    this.blogObject.endDate = this.datepipe.transform(this.myFormEdit.value.endDate, 'dd/MM/yyyy');
  }
  else
  {
    this.blogObject.endDate = this.myFormEdit.value.endDate
  }
  this.blogObject.itinerary=this.myFormEdit.value.itinerary;
  this.service.postResponseMethod(this.blogObject,"updateEvent").subscribe(response=>{
    if(response.responseCode==200){
      this.getEvent()
     this.spinner.hide();
     $("#myModalEdit").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
  }
  },err=>{
    this.spinner.hide();
     alert("Something went wrong!");
  })
}
onSelectFile_editblogImg(event) {
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.upEventImg = event.target.result;
      this.blogObject.image=this.upEventImg
    }
  }
}
onSelectFile_editVerImg(event){
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.upVerEventImg = event.target.result;
      this.blogObject.verticalImage=this.upVerEventImg;
    }
  }
}
onSelectFile_editauthImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event:any) => {
      this.Up_profileImg = event.target.result;
      this.blogObject.authorprofilePic=this.Up_profileImg
    }
  }
}
delEvent(){
  let dataInfo= {
    "id":this.blogObject._id
  }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"deleteEvent").subscribe(response=>{
    if(response.responseCode==200){
    this.getEvent()
    this.spinner.hide();
    $("#delete").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
  }
  },err=>{
    this.spinner.hide();
   })
}
cnclDelEvent(){
  $("#delete").modal("hide");
}
searchBlog(){
  let dataInfo= {
    "srchBlog" :this.data.search
  }
  this.service.postResponseMethod(dataInfo,"search_blog").subscribe(response=>{
    if(response.responseCode==200){
    this.blogs=response.data
    } else{
    alert(response.responseMessage);
  }
  },err=>{
    })
  }
  getTag(){
    this.spinner.show();
    this.service.getResponseMethod("get_tag").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        this.tagList=res.tagLists
        }
     },
     (err)=>{
      this.spinner.hide();
    });
  }
onSelectTag(){
this.tagArray.push(this.myForm.value.tags)
}
addItinerary(){
  this.itinerary.push([]);
}
remItinerary(val){
  this.index=val
  if(this.index != -1) {
    this.itinerary.splice(this.index, 1);
  }
}
remTag(val){
  this.index=val
  if(this.index != -1) {
    this.tagArray.splice(this.index, 1);
  }
}
onChangeTag(){
  this.editTags.push(this.blogObject.tags)
}
updateTag(val){
  this.index=val
  if(this.index != -1) {
    this.editTags.splice(this.index, 1);
  }
}
getCity(){
  this.spinner.show();
  this.service.getResponseMethod("get_city").subscribe(res=>{
    if(res.responseCode==200){
      this.spinner.hide();
      this.cityList=res.cityList
      }
   },
   (err)=>{
    this.spinner.hide();
  });
}
getCategory(){
  this.spinner.show();
  this.service.getResponseMethod("getCategory").subscribe(res=>{
    if(res.responseCode==200){
      this.spinner.hide();
      this.categoryList=res.succ
      }
   },
   (err)=>{
    this.spinner.hide();
  });
}
}
