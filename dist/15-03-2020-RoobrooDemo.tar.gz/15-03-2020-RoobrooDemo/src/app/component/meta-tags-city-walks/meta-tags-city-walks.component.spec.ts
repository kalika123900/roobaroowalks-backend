import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetaTagsCityWalksComponent } from './meta-tags-city-walks.component';

describe('MetaTagsCityWalksComponent', () => {
  let component: MetaTagsCityWalksComponent;
  let fixture: ComponentFixture<MetaTagsCityWalksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetaTagsCityWalksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetaTagsCityWalksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
