import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { RestDataService } from '../../rest-data.service';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-add-testimonials',
  templateUrl: './add-testimonials.component.html',
  styleUrls: ['./add-testimonials.component.css']
})
export class AddTestimonialsComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  memories:any=[];
  reviews:any={};
  edit:any={};
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) { 
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      idesc: new FormControl('',[Validators.required]),
    
}) 
}

  ngOnInit() {
   this.getActivities() 
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  getActivities(){
    this.spinner.show();
    this.service.getResponseMethod("get_addReview").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
      this.memories=res.memories[0].review;
        }
     
     },
     (err)=>{console.log(err)
      this.spinner.hide();
    });
  }
  testimonial(){
    let dataInfo= {
      "rvwName" :this.myForm.value.title,
      "rvwTestm" :this.myForm.value.idesc,
      "rvwPrfleImgs" : this.imgUrl
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo,"add_review").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
      console.log("add_review==>>"+JSON.stringify(response))
      this.getActivities()
      $("#myModal").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("add_review_error==>>"+JSON.stringify(err))
    })
  }
  editData(val){
    this.reviews=val
    this.edit.title=this.reviews.rvwName
    this.edit.des=this.reviews.rvwTestm
    this.imgUrl=this.reviews.rvwPrfleImgs
    this.edit.id=this.reviews._id

  }
  update(){
    let dataInfo= {
      "addRvwId":this.edit.id,
      "rvwName":this.edit.title,
      "rvwTestm" : this.edit.des,
      "rvwPrfleImgs" : this.imgUrl
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo,"edit_addReview").subscribe(response=>{
      if(response.responseCode==200){
        this.spinner.hide();
      console.log("edit_addReview==>>"+JSON.stringify(response))
      this.getActivities()
      $("#edit").modal("hide");
     } else{
      this.spinner.hide();
       alert("Something went wrong!")
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
      console.log("edit_addReview_error==>>"+JSON.stringify(err))
    })  
  }
  onSelectFile_img(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); 

      reader.onload = (event:any) => {
        this.imgUrl = event.target.result;
        console.log(this.imgUrl);
      }
    }
  }
  delete(val){
    this.reviews=val
    this.edit.id=this.reviews._id
  }
  confirmDel(){
    let dataInfo= {
    "addRvwId" :this.edit.id
  }
  this.spinner.show();
  this.service.postResponseMethod(dataInfo,"dlt_addReview").subscribe(response=>{
    if(response.responseCode==200){
    console.log("dlt_addReview==>>"+JSON.stringify(response))
    this.getActivities()
    this.spinner.hide();
    $("#delete").modal("hide");
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}  

  },err=>{
    this.spinner.hide();
    console.log("dlt_addReview_error==>>"+JSON.stringify(err))
  })  
  }
  cnclDel(){
    $("#delete").modal("hide");
  }
}
