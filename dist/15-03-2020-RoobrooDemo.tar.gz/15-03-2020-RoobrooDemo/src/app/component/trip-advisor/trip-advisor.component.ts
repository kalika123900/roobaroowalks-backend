import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-trip-advisor',
  templateUrl: './trip-advisor.component.html',
  styleUrls: ['./trip-advisor.component.css']
})
export class TripAdvisorComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  advisorLink:any=[];
  advisor:any={};
  edit:any={};
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) { 
    this.myForm = new FormGroup({
      link: new FormControl('',[Validators.required]),
     
    
}) }

  ngOnInit() {
   this.getAdvisor()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  } 
  getAdvisor(){
    this.spinner.show();
    this.service.getResponseMethod("get_tripAdvsr").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.advisorLink=res.data[0].trpAdvisor;
        }
     
     },
     (err)=>{  this.spinner.hide();
      console.log(err)
    });
  }
  editData(val){
    this.advisor=val
    this.edit.logo= this.advisor.trpLogoLnk
    this.imgUrl= this.advisor.trpImgs
    this.edit.readLnk= this.advisor.trpReadLnk
    this.edit.writeLnk= this.advisor.trpWriteLnk
    this.edit.id=this.advisor._id
  }
  update(){
    let dataInfo= {
      "trpAdvId": this.edit.id,
      "trpLogoLnk": this.edit.logo,
    "trpReadLnk": this.edit.readLnk,
    "trpWriteLnk": this.edit.writeLnk,
    "trpImgs":this.imgUrl
        
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"edit_trpAdvsr").subscribe(response=>{
          if(response.responseCode==200){
          console.log("edit_trpAdvsr==>>"+JSON.stringify(response))
          this.getAdvisor()
          this.spinner.hide();
          $("#myModal").modal("hide");
         

         } else{
          this.spinner.hide();
           alert("Something went wrong!")
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
          console.log("edit_trpAdvsr_error==>>"+JSON.stringify(err))
        })
  }

  // save(){
  //   // alert("ok")
  //   let dataInfo= {
  //     "tripLink":this.myForm.value.link

  //   }
  //   this.service.postResponseMethod(dataInfo,"trip_advsr").subscribe(response=>{
  //     if(response.responseCode==200){
  //     console.log("trip_advsr==>>"+JSON.stringify(response))
  //    } else{
  //     alert(response.responseMessage);
  // }  
  
  //   },err=>{
  //     console.log("trip_advsr_error==>>"+JSON.stringify(err))
  //   })
  //   }
    onSelectFile_img(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
  
        reader.readAsDataURL(event.target.files[0]); 
  
        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          console.log(this.imgUrl);
        }
      }
  }
}
