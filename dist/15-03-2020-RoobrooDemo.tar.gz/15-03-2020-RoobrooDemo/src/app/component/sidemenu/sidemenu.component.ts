import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SidemenuComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  city_management(){
    this.router.navigate(['city-mngmnt'])
  }
  home(){
    this.router.navigate(['home'])
  }
booking(){
  this.router.navigate(['booking'])
}
blog(){
  this.router.navigate(['blog'])
}
events(){
  this.router.navigate(['events'])
}
histri(){
  this.router.navigate(['history'])
}
culture(){
  this.router.navigate(['culture'])
}
about(){
  this.router.navigate(['about'])
}
career(){
  this.router.navigate(['career'])
}
contact(){
  this.router.navigate(['contact'])

}
guideMngmnt(){
  this.router.navigate(['guide-mngmnt'])

}
trvlrDetail(){
  this.router.navigate(['trvlr-res-details'])
}
metaTags(){
  this.router.navigate(['meta-tags'])
}
metaTagsCities(){
  this.router.navigate(['meta-tags-cities'])
}
metaTagsCityWalks(){
  this.router.navigate(['meta-tags-city-walks'])
}
metaTagsBlogPosts(){
  this.router.navigate(['meta-tags-blog-posts'])
}


}
