import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-mobile-app',
  templateUrl: './mobile-app.component.html',
  styleUrls: ['./mobile-app.component.css']
})
export class MobileAppComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  banners:any=[];
  activity:any;
  mobApp:any={};
  edit:any={};
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) { 
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      link: new FormControl('',[Validators.required,Validators.pattern(/(http[s]?:\/\/)?[^\s(["<,>]*\.[^\s[",><]*/)]),
    
}) 
  }

  ngOnInit() {
   this.getMobApp()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  getMobApp(){
    this.spinner.show();
    this.service.getResponseMethod("get_mobApp").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.activity=res.data[0].mobleApp;
        }
      
     },
     (err)=>{ this.spinner.hide();
      console.log(err)
    });
  }
  editData(val){
this.mobApp=val
this.edit.title=this.mobApp.mobTitle
this.edit.desc=this.mobApp.mobDesc
this.edit.link=this.mobApp.mobLink
this.imgUrl=this.mobApp.mobImgs
this.edit.id=this.mobApp._id
this.edit.iOSLink=this.mobApp.iOSLink

  }
  update(){
    let dataInfo= {
      "mobAppId":this.edit.id,
      "mobTitle":this.edit.title,
    "mobImgs":this.imgUrl,
    "mobDesc":this.edit.desc,
    "mobLink":this.edit.link,
    "iOSLink":this.edit.iOSLink
        
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"edit_mobApp").subscribe(response=>{
          if(response.responseCode==200){
          console.log("edit_mobApp==>>"+JSON.stringify(response))
          this.getMobApp()
          this.spinner.hide();
          $("#edit").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("edit_mobApp_error==>>"+JSON.stringify(err))
        })
  }
  save(){
    // alert("ok")
    let dataInfo= {
      "mobTitle":this.myForm.value.title,
      "mobImgs": this.imgUrl,
      "mobDesc":this.myForm.value.desc,
      "mobLink":this.myForm.value.link
    }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo,"mobile_app").subscribe(response=>{
      if(response.responseCode==200){
      console.log("mobile_app==>>"+JSON.stringify(response))
      this.getMobApp()
      this.spinner.hide();
      $("#myModal").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("mobile_app_error==>>"+JSON.stringify(err))
    })
    }
    onSelectFile_img(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
  
        reader.readAsDataURL(event.target.files[0]); 
  
        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          console.log(this.imgUrl);
        }
      }
  }
}
