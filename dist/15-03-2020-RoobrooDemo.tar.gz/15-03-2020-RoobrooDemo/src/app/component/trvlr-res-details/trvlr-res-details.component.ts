import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, Validators, FormControl } from '@angular/forms';
declare var $:any;
@Component({
  selector: 'app-trvlr-res-details',
  templateUrl: './trvlr-res-details.component.html',
  styleUrls: ['./trvlr-res-details.component.css']
})
export class TrvlrResDetailsComponent implements OnInit {
  travResTab:any='AddBanner';
  banner:any=[]
  bnrEdit:any={};
  bnrImg:any;
  myForm: any = FormGroup;
  cityDetails:any=[];
  walkUrl:any;
  walkList:any=[];
  walkDetails:any=[];
  walkObj:any={};
  up_walkUrl:any;
  articles:any=[];
  articleObj:any=[];
  revUrl:any;
  reviews:any=[];
  revObj:any={};
  UpRevUrl:any;
  constructor(private service: RestDataService,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      city: new FormControl('',[Validators.required]),
      walkTitle: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
      art_1: new FormControl('',[Validators.required]),
      artTitle: new FormControl('',[Validators.required]),
      art_2: new FormControl('',[Validators.required]),
      revTitle: new FormControl('',[Validators.required]),
      revLink: new FormControl('',[Validators.required]),

    })
   }

  ngOnInit() {
    this.getBanr()
   this.getCity()
   this.getWalk()
   this.getAticle()
   this.getRev()
  }
  getCity(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  getWalk(){
    this.spinner.show();
    this.service.getResponseMethod("getWalk_trav").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.walkDetails=res.result[0].addWalk;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  managetab(val){
    this.travResTab=val;
    // alert(this.travResTab)
  }
  getBanr(){
    this.spinner.show();
    this.service.getResponseMethod("getaddBanner").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log("getBanner===>"+JSON.stringify(res));
        this.banner=res.tempData;
        }

     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    });
  }
  editBnr(val){
    this.bnrEdit=val
  }
  up_Bnr(){
    this.spinner.show();
    this.service.postResponseMethod(this.bnrEdit,"editaddBanner").subscribe(response=>{
      if(response.responseCode==200){
        this.getBanr()
       this.spinner.hide();
       $("#myModal33").modal("hide");
      console.log("editaddBanner==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("editaddBanner_error==>>"+JSON.stringify(err))
    })
    }
    onSelectFile_bnrImg(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();

        reader.readAsDataURL(event.target.files[0]);

        reader.onload = (event:any) => {
          this.bnrImg = event.target.result;
          this.bnrEdit.bannerImage=this.bnrImg
          // console.log(this.bnrImg);
        }
      }
  }
  onSelectWalk(){
    this.spinner.show();
    let dataInfo= {
      "cityId":this.myForm.value.city.split('@')[0],
}
    this.service.postResponseMethod(dataInfo,"getWalkByCity").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       this.walkList=response.result
      console.log("getWalkByCity==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("getWalkByCity_error==>>"+JSON.stringify(err))
    })
  }
  onSelectWalkEdit(){
    this.spinner.show();
    let dataInfo= {
      "cityId":this.walkObj.city.split('@')[0],
}
    this.service.postResponseMethod(dataInfo,"getWalkByCity").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
       this.walkList=response.result
      console.log("getWalkByCity==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("getWalkByCity_error==>>"+JSON.stringify(err))
    })
  }
  addWalk(){
    this.spinner.show();
    let dataInfo= {
      "walkTitle":this.myForm.value.walkTitle.split('@')[1],
      "description":this.myForm.value.desc,
      "cityId":this.myForm.value.city.split('@')[0],
      "walkId":this.myForm.value.walkTitle.split('@')[0],
      "cityName":this.myForm.value.city.split('@')[1],
        "image":this.walkUrl
}
    this.service.postResponseMethod(dataInfo,"addWalk_trav").subscribe(response=>{
      if(response.responseCode==200){
        this.getWalk()
       this.spinner.hide();
       $("#myModalTrvResDetail").modal("hide");
      console.log("addWalk_trav==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("addWalk_trav_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_walkImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.walkUrl = event.target.result;
        console.log(this.walkUrl);
      }
    }
  }
  editWalk(val){
    this.walkObj=val
  }
  updateWalk(){
    this.spinner.show()
    this.walkObj.cityId=this.walkObj.city.split('@')[0],
    this.walkObj.cityName=this.walkObj.city.split('@')[1],
    this.walkObj.walkId=this.walkObj.walkTitle.split('@')[0],
    this.walkObj.walkTitle=this.walkObj.walkTitle.split('@')[1],
    this.walkObj.city=this.walkObj.cityId+"@"+this.walkObj.cityName,
    this.walkObj.walk=this.walkObj.walkId+"@"+this.walkObj.walkTitle
    this.service.postResponseMethod(this.walkObj,"editWalk_trav").subscribe(response=>{
      if(response.responseCode==200){
        this.getWalk()
       this.spinner.hide();
       $("#myModalEdit").modal("hide");
      console.log("editWalk_trav==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("editWalk_trav_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_up_walkImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.up_walkUrl = event.target.result;
        this.walkObj.image=this.up_walkUrl
        // console.log(this.up_walkUrl);
      }
    }
  }
  delWalk(){
    let dataInfo= {
        "id" :this.walkObj._id
      }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo,"deleteWalk_trav").subscribe(response=>{
      if(response.responseCode==200){
      console.log("deleteWalk_trav==>>"+JSON.stringify(response))
        this.getWalk()
      this.spinner.hide();
      $("#delete").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("deleteWalk_trav_error==>>"+JSON.stringify(err))
    })
  }
  cnclDelWalk(){
    $("#delete").modal("hide");
  }
//   addArticle(){
//     this.spinner.show();
//     let dataInfo= {
//       "firstArticle":this.myForm.value.art_1,
//       "title":this.myForm.value.artTitle,
//       "secondArticle":this.myForm.value.art_2
// }
//     this.service.postResponseMethod(dataInfo,"addArticle").subscribe(response=>{
//       if(response.responseCode==200){
//         this.getAticle()
//        this.spinner.hide();
//        $("#myModal44").modal("hide");
//       console.log("addArticle==>>"+JSON.stringify(response))
//      } else{
//       this.spinner.hide();
//       alert(response.responseMessage);
//   }

//     },err=>{
//       this.spinner.hide();
//        alert("Something went wrong!")
//       console.log("addArticle_error==>>"+JSON.stringify(err))
//     })
//   }
  getAticle(){
    this.spinner.show();
    this.service.getResponseMethod("getArticle").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.articles=res.result[0].article
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  editArticle(val){
    this.articleObj=val
  }
  updateArt(){
    this.spinner.show();
    this.service.postResponseMethod(this.articleObj,"editArticle").subscribe(response=>{
      if(response.responseCode==200){
        this.getAticle()
       this.spinner.hide();
       $("#myModal44Edit").modal("hide");
      console.log("editArticle==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("editArticle_error==>>"+JSON.stringify(err))
    })
  }

  onSelectFile_revImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.revUrl = event.target.result;
        // console.log(this.up_walkUrl);
      }
    }
  }
  addRev(){
    this.spinner.show();
    let dataInfo= {
      "title":this.myForm.value.revTitle,
      "link":this.myForm.value.revLink,
      "image":this.revUrl

}
    this.service.postResponseMethod(dataInfo,"addReview").subscribe(response=>{
      if(response.responseCode==200){
        this.getRev()
       this.spinner.hide();
       $("#myModal55").modal("hide");
      console.log("addReview==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("addReview_error==>>"+JSON.stringify(err))
    })
  }
  getRev(){
    this.spinner.show();
    this.service.getResponseMethod("getReview").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res));
        this.reviews=res.result[0].addReview
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  editRvw(val){
    this.revObj=val
  }
  updateRev(){
    this.spinner.show();
    this.service.postResponseMethod(this.revObj,"editReview").subscribe(response=>{
      if(response.responseCode==200){
        this.getRev()
       this.spinner.hide();
       $("#myModal55Edit").modal("hide");
      console.log("editReview==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("editReview_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_upRevImg(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      reader.onload = (event:any) => {
        this.UpRevUrl = event.target.result;
        this.revObj.image=this.UpRevUrl
        // console.log(this.up_walkUrl);
      }
    }
  }
  delRev(){
    let dataInfo= {
      "id":this.revObj._id
      }
    this.spinner.show();
    this.service.postResponseMethod(dataInfo,"deleteReview").subscribe(response=>{
      if(response.responseCode==200){
      console.log("deleteReview==>>"+JSON.stringify(response))
      this.getRev()
      this.spinner.hide();
      $("#deleteRev").modal("hide");
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }

    },err=>{
      this.spinner.hide();
      console.log("deleteReview_error==>>"+JSON.stringify(err))
    })
  }
  cnclDelRev(){
    $("#deleteRev").modal("hide");
  }
}
