import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrvlrResDetailsComponent } from './trvlr-res-details.component';

describe('TrvlrResDetailsComponent', () => {
  let component: TrvlrResDetailsComponent;
  let fixture: ComponentFixture<TrvlrResDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrvlrResDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrvlrResDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
