import { Component, OnInit } from '@angular/core';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-unforgettable-memories',
  templateUrl: './unforgettable-memories.component.html',
  styleUrls: ['./unforgettable-memories.component.css']
})
export class UnforgettableMemoriesComponent implements OnInit {
  myForm: any = FormGroup;
  imgUrl:any;
  memory:any=[];
  mem_row:any={}
  edit:any={};

  // des:any;title:any;img:any;id:any;
  constructor(private service: RestDataService,private router: Router,private spinner: NgxSpinnerService) { 
    this.myForm = new FormGroup({
      desc: new FormControl('',[Validators.required]),
      img: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      list: new FormControl('',[Validators.required]),
    
}) 
}

  ngOnInit() {
   this.getMemory()
  }
  getMemory(){
    this.spinner.show();
    this.service.getResponseMethod("get_memries").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
      this.memory=res.memories[0].memory
        }
     
  
    
     },
     (err)=>{  this.spinner.hide();
      console.log(err)
    });
  }
  edit_mem(val){
this.mem_row=val
this.edit.des=this.mem_row.memDesc
this.edit.title=this.mem_row.memTitle
this.imgUrl=this.mem_row.memImgs
this.edit.id=this.mem_row._id
// alert(this.edit.id)

  }
  update(){
    let dataInfo= {
      "memId" :this.edit.id,
      "memTitle" :this.edit.title,
      "memDesc" :this.edit.des,
      "memImgs" : this.imgUrl
        
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"edit_memries").subscribe(response=>{
          if(response.responseCode==200){
          console.log("edit_memries==>>"+JSON.stringify(response))
          this.getMemory()
          this.spinner.hide();
          $("#edit").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{  this.spinner.hide();
         alert("Something went wrong!")
          console.log("edit_memries_error==>>"+JSON.stringify(err))
        })
  }
  // saveMemory(){
  //   // alert("ok")
  //   let dataInfo= {
  //     "admn_Id" :"5bd19293f622d5ae5e6e48d3",
  //     "memTitle" :this.myForm.value.title,
  //     "memDesc" :this.myForm.value.desc,
  //     "memImgs" : this.imgUrl 
    
  //   }
  //   this.service.postResponseMethod(dataInfo,"memories").subscribe(response=>{
  //     if(response.responseCode==200){
  //     console.log("memories==>>"+JSON.stringify(response))
  //    } else{
  //     alert(response.responseMessage);
  // }  
  
  //   },err=>{
  //     console.log("memories_error==>>"+JSON.stringify(err))
  //   })
  //   }
    onSelectFile_img(event) {
      // this.imgUrl = "assets/img/woodcreek_middle_school.png"
      if (event.target.files && event.target.files[0]) {
        var reader = new FileReader();
  
        reader.readAsDataURL(event.target.files[0]); 
  
        reader.onload = (event:any) => {
          this.imgUrl = event.target.result;
          console.log(this.imgUrl);
        }
      }
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  } 
}
