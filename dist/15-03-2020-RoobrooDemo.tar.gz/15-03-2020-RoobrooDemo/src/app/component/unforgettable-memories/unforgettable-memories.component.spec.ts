import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnforgettableMemoriesComponent } from './unforgettable-memories.component';

describe('UnforgettableMemoriesComponent', () => {
  let component: UnforgettableMemoriesComponent;
  let fixture: ComponentFixture<UnforgettableMemoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnforgettableMemoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnforgettableMemoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
