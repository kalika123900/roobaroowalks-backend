import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  addBanner(){
    this.router.navigate(['addbanner'])
  }
  addTestimonial(){
    this.router.navigate(['add-testimonials']) 
  }
  unfor_memories(){
    this.router.navigate(['unforgettable-memories'])  
  }
  mobileApp(){
    this.router.navigate(['mobile-app']) 
  }
  travellers(){
    this.router.navigate(['traveller-res-centre']) 
  }
  readwrite_review(){
    this.router.navigate(['read-write-review']) 
  }
  tripAdvisor(){
    this.router.navigate(['trip-advisor'])
  }
  key_point(){
    this.router.navigate(['key-point'])  
  }
  social(){
    this.router.navigate(['social'])  
  }
  trvlrDetail(){
    this.router.navigate(['trvlr-res-details'])  
  }
 
}
