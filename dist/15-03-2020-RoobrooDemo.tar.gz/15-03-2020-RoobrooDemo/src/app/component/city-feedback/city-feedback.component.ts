import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $:any;
@Component({
  selector: 'app-city-feedback',
  templateUrl: './city-feedback.component.html',
  styleUrls: ['./city-feedback.component.css']
})
export class CityFeedbackComponent implements OnInit {
  myForm: any = FormGroup;
  cityDetails:any=[];
  cl_ImgUrl:any;
  logo_imgUrl:any;
  feedback:any=[];
  object:any={};
  up_cli_imgUrl:any;
  up_logo_imgUrl:any;
  data:any={}
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) {
    this.myForm = new FormGroup({
      city: new FormControl('',[Validators.required]),
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
    })
   }

  ngOnInit() {
    this.getCityList()
    this.getCityFeedbck()
  }
  city_management(){
    this.router.navigate(['city-mngmnt'])
  }
  getCityList(){
    this.spinner.show();
    this.service.getResponseMethod("get_city").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.cityDetails=res.cityList;
        }
     },
     (err)=>{this.spinner.hide();
      console.log(err)
    });
  }
  onSelectFile_clientImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); 

      reader.onload = (event:any) => {
        this.cl_ImgUrl = event.target.result;
        console.log(this.cl_ImgUrl);
      }
    }
}
onSelectFile_logoImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();

    reader.readAsDataURL(event.target.files[0]); 

    reader.onload = (event:any) => {
      this.logo_imgUrl = event.target.result;
      console.log(this.logo_imgUrl);
    }
  }
}
  addCityFeedbck(){
    this.spinner.show();
    let dataInfo= {
"cityId" :this.myForm.value.city,
"logo_img":this.logo_imgUrl,
"client_img":this.cl_ImgUrl,
"desc":this.myForm.value.desc,
"title":this.myForm.value.title,
}
    this.service.postResponseMethod(dataInfo,"add_City_feedback").subscribe(response=>{
      if(response.responseCode==200){
       this.getCityFeedbck()
       this.spinner.hide();
       $("#feedback").modal("hide");
      //  this.actionType='modal'
      console.log("add_City_feedback==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("add_City_feedback_error==>>"+JSON.stringify(err))
    })
  }
  getCityFeedbck(){
    this.spinner.show();
    // let dataInfo= {
    //   "cityId" :this.myForm.value.city,
    //   }
    this.service.postResponseMethod({},"get_cityFeedback").subscribe(response=>{
      if(response.responseCode==200){
       this.spinner.hide();
      this.feedback=response.feedbck
      console.log("get_cityFeedback==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("get_cityFeedback_error==>>"+JSON.stringify(err))
    })
}
editFeedback(val){
  this.object=val
}
editCityFeedbck(){
  this.spinner.show();
  console.log("console==>"+JSON.stringify(this.object))
  this.service.postResponseMethod(this.object,"edit_cityFeedback").subscribe(response=>{
    if(response.responseCode==200){
     this.getCityFeedbck()
     this.spinner.hide();
     $("#feedbackEdit").modal("hide");
    //  this.actionType='modal'
    console.log("edit_cityFeedback==>>"+JSON.stringify(response))
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}  

  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
    console.log("edit_cityFeedback_error==>>"+JSON.stringify(err))
  })
}
onSelectFile_up_clientImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();

    reader.readAsDataURL(event.target.files[0]); 

    reader.onload = (event:any) => {
      this.up_cli_imgUrl = event.target.result;
      this.object.client_img=this.up_cli_imgUrl
      // console.log(this.up_cli_imgUrl);
    }
  }
}
onSelectFile_up_logoImg(event) {
  // this.imgUrl = "assets/img/woodcreek_middle_school.png"
  if (event.target.files && event.target.files[0]) {
    var reader = new FileReader();

    reader.readAsDataURL(event.target.files[0]); 

    reader.onload = (event:any) => {
      this.up_logo_imgUrl = event.target.result;
      this.object.logo_img=this.up_logo_imgUrl
      // console.log(this.up_logo_imgUrl);
    }
  }
}
cnfrmDel(){
  this.spinner.show();
  let dataInfo= {
    "feedbckId" :this.object._id
  }
  this.service.postResponseMethod(dataInfo,"delete_cityFeedback").subscribe(response=>{
    if(response.responseCode==200){
     this.spinner.hide();
     console.log("delete_cityFeedback==>>"+JSON.stringify(response));
     $("#delete").modal("hide");
     this.getCityFeedbck()
     } else{
      this.spinner.hide();  
      alert(response.responseMessage);
}   
  },err=>{
    this.spinner.hide();
    console.log("delete_cityFeedback_error==>>"+JSON.stringify(err))
  }) 
}
cnclDel(){
 $("#delete").modal("hide");
}
searchFeedbck(){
let dataInfo= {
  "srchCtyFedbck" :this.data.search
}
this.service.postResponseMethod(dataInfo,"search_cityFeedback").subscribe(response=>{
  if(response.responseCode==200){
  this.feedback=response.data
  console.log("search_cityFeedback==>>"+JSON.stringify(response))
 } else{
  alert(response.responseMessage);
}  

},err=>{
  console.log("search_cityFeedback_error==>>"+JSON.stringify(err))
})
}
}
