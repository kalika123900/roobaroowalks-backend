import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CityFeedbackComponent } from './city-feedback.component';

describe('CityFeedbackComponent', () => {
  let component: CityFeedbackComponent;
  let fixture: ComponentFixture<CityFeedbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CityFeedbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CityFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
