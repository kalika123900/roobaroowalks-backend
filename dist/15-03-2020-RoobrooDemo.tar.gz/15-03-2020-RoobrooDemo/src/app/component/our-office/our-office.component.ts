import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { RestDataService } from '../../rest-data.service';

declare var $:any;
@Component({
  selector: 'app-our-office',
  templateUrl: './our-office.component.html',
  styleUrls: ['./our-office.component.css']
})
export class OurOfficeComponent implements OnInit {
  imgUrl:any;
  myForm: any = FormGroup;
  office:any=[];
  object:any={};
  updateImg:any;
  constructor(private router: Router,private spinner: NgxSpinnerService,private service: RestDataService) { 
    this.myForm = new FormGroup({
      title: new FormControl('',[Validators.required]),
      desc: new FormControl('',[Validators.required]),
    })
  }
 
  ngOnInit() {
    this.getOffice()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  contact(){
    this.router.navigate(['contact']) 
 
  }
  onSelectFile_img(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); 

      reader.onload = (event:any) => {
        this.imgUrl = event.target.result;
        console.log(this.imgUrl);
      }
    }
}
addOffice(){
  this.spinner.show();
  let dataInfo= {
    
  "officeTitle": this.myForm.value.title,
  "officeImage": this.imgUrl,
  "officeDescription":this.myForm.value.desc
  }
  this.service.postResponseMethod(dataInfo,"AddOurOffice").subscribe(response=>{
    if(response.responseCode==200){
     this.getOffice()
     this.spinner.hide();
     $("#feedback").modal("hide");
    //  this.actionType='modal'
    console.log("AddOurOffice==>>"+JSON.stringify(response))
   } else{
    this.spinner.hide();
    alert(response.responseMessage);
}  

  },err=>{
    this.spinner.hide();
     alert("Something went wrong!")
    console.log("AddOurOffice_error==>>"+JSON.stringify(err))
  })
  }
  getOffice(){
    this.spinner.show();
    this.service.getResponseMethod("getOurOffice").subscribe(res=>{
      if(res.responseCode==200){
      this.spinner.hide();
      console.log(JSON.stringify(res)); 
      this.office=res.officeData.office;
      }
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    });
  }
  editOffice(val){
    this.object=val
  }
  updateOffice(){
    this.spinner.show();
    this.service.postResponseMethod(this.object,"edit_ourOffice").subscribe(response=>{
      if(response.responseCode==200){
        this.getOffice()
       this.spinner.hide();
       $("#update").modal("hide");
      //  this.actionType='modal'
      console.log("edit_ourOffice==>>"+JSON.stringify(response))
     } else{
      this.spinner.hide();
      alert(response.responseMessage);
  }  
  
    },err=>{
      this.spinner.hide();
       alert("Something went wrong!")
      console.log("edit_ourOffice_error==>>"+JSON.stringify(err))
    })
  }
  onSelectFile_EditImg(event) {
    // this.imgUrl = "assets/img/woodcreek_middle_school.png"
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.readAsDataURL(event.target.files[0]); 
  
      reader.onload = (event:any) => {
        this.updateImg = event.target.result;
        this.object.officeImage= this.updateImg
        // console.log(this.updateImg);
      }
    }
}
cnfrmDel(){
let dataInfo= {
  "officeId":this.object._id
  }
this.spinner.show();
this.service.postResponseMethod(dataInfo,"delete_ourOffice").subscribe(response=>{
  if(response.responseCode==200){
  console.log("delete_ourOffice==>>"+JSON.stringify(response))
  this.getOffice()
  this.spinner.hide();
  $("#delete").modal("hide");
 } else{
  this.spinner.hide();
  alert(response.responseMessage);
}  

},err=>{
  this.spinner.hide();
  console.log("delete_ourOffice_error==>>"+JSON.stringify(err))
}) 
} 
cnclDel(){
$("#delete").modal("hide");
}
}
