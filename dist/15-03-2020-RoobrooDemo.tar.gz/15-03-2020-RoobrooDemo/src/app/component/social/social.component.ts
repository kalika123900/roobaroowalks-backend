import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { RestDataService } from '../../rest-data.service';
import { NgxSpinnerService } from 'ngx-spinner';

declare var $:any;
@Component({
  selector: 'app-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.css']
})
export class SocialComponent implements OnInit {
  socialLink:any=[];
  social:any={};
  edit:any={};
  constructor(private router: Router,private service: RestDataService,private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.getSocial()
  }
  dashboard(){
    this.router.navigate(['dashboard'])
  }
  home(){
    this.router.navigate(['home'])
  }
  getSocial(){
    this.spinner.show();
    this.service.getResponseMethod("get_social").subscribe(res=>{
      if(res.responseCode==200){
        this.spinner.hide();
        console.log(JSON.stringify(res)); 
        this.socialLink=res.socialData[0].social;
        }
     
     },
     (err)=>{
      this.spinner.hide();
      console.log(err)
    }); 
  }
  editData(val){
this.social=val
this.edit.fbLink=this.social.fcebookLnk
this.edit.instaLnk=this.social.instaLnk
this.edit.id=this.social._id

  }
  update(){
    let dataInfo= {
      "socialId":this.edit.id,
      "fcebookLnk":this.edit.fbLink,
     "instaLnk":this.edit.instaLnk
        }
        this.spinner.show();
        this.service.postResponseMethod(dataInfo,"edit_social").subscribe(response=>{
          if(response.responseCode==200){
          console.log("edit_social==>>"+JSON.stringify(response))
          this.getSocial()
          this.spinner.hide();
          $("#edit").modal("hide");
         } else{
          this.spinner.hide();
          alert(response.responseMessage);
      }  
      
        },err=>{
          this.spinner.hide();
           alert("Something went wrong!")
          console.log("edit_social_error==>>"+JSON.stringify(err))
        })
  }
}
