import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RestDataService {
  // ----------------- for live ---------------------------
  baseUrl="https://admin.roobaroowalks.com/"

  // ----------------- for local --------------------------
  // baseUrl="http://localhost:5000/"
  stepNo:number;
  constructor(private http: HttpClient) { }

getResponseMethod(apiName): Observable < any> {
let httpOptions = {
headers: new HttpHeaders({
'Content-Type': 'application/json',
//'jwt': localStorage.getItem("token")
})
};
return this.http.get(this.baseUrl+apiName,httpOptions);
}

/**************** Function for all POST type API methods ********************/
postResponseMethod(dataInfo,apiName): Observable<any>{
console.log("hhh=>>>", dataInfo)
let httpOptions = {
headers: new HttpHeaders({
'Content-Type': 'application/json',
//'jwt': localStorage.getItem("token")
})
};
return this.http.post(this.baseUrl+apiName, dataInfo,httpOptions);

}


}
